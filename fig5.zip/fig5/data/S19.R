setwd("C:\\ondrive备份\\AMD博士课题\\超微型微生物\\分析\\virus\\all_vh\\without_ref\\Manuscript\\final\\revision\\fig5")

library(dplyr)
library(ppcor)
library(ggmagnify)

data <- read.table("data\\s19_data.tab", sep = "\t",header = TRUE,stringsAsFactors = FALSE, check.names = FALSE)

cor.test(data$MAS4_virus85,data$allSRMhost_MAS4_virus85)
plot(data$MAS4_virus85,data$allSRMhost_MAS4_virus85)

# 1
v85 = data[data$MAS4_virus85 > 0,]
cor.test(v85$MAS4_virus85,v85$allSRMhost_MAS4_virus85)
plot(v85$MAS4_virus85,v85$allSRMhost_MAS4_virus85)
v852 = v85[v85$allSRMhost_MAS4_virus85<60,]
cor.test(v852$MAS4_virus85,v852$allSRMhost_MAS4_virus85)
plot(v852$MAS4_virus85,v852$allSRMhost_MAS4_virus85)
#vv = v85[v85$MAS4_virus85<2,]
#cor.test(vv$MAS4_virus85,vv$allSRMhost_MAS4_virus85)
p1=ggplot(v85, aes(x = MAS4_virus85, y = allSRMhost_MAS4_virus85)) +
  geom_point(size=2,color="gray")+
  geom_smooth(method="lm",fill= NA,level=0, color = "#4682B4")+
  stat_cor(label.sep = '\n')+
  labs(x="EC",y="Lysogenic rate (%)")+
  theme_bw(base_size = 18)+
  theme(panel.border = element_blank(),
        panel.grid = element_blank(),
        axis.line = element_line(),axis.text.y = element_text(angle = 90, hjust = 0.5, vjust = 0.5))
from = list(0,3,0,25)
to = list(35,55,10,40)
p2=p1+geom_magnify(from=from,to=to)

# 2
v60 = data[data$WY1_virus60 > 0,]
cor.test(v60$WY1_virus60,v60$WY5.bin62)
v60 = v60[v60$WY5.bin62>0,]
cor.test(v60$WY1_virus60,v60$WY5.bin62)
plot(v60$WY1_virus60,v60$WY5.bin62)
cor.test(data$WY1_virus60,data$WY5.bin62)
plot(data$WY1_virus60,data$WY5.bin62)

v60h = data[data$WY5.bin62>0,]
cor.test(v60h$WY1_virus60,v60h$WY5.bin62)
plot(v60h$WY1_virus60,v60h$WY5.bin62)

v60h$virus_group <- factor(
  ifelse(v60h$WY1_virus60 == 0, "Virus-negative", "Virus-positive"),
  levels = c("Virus-negative", "Virus-positive")
)



p3=ggplot(v60h, aes(x = virus_group, y = WY5.bin62, fill = virus_group)) +
  geom_boxplot() +
  labs(x = "Sample group", y = "Abundance of WY5.bin62")+
  ylim(c(0,5))+
  stat_compare_means(method = "wilcox.test", label = "p.signif", size = 6,hide.ns = TRUE)+
  theme_bw(base_size = 18)+
  theme(panel.border = element_blank(),legend.position = "none",
        panel.grid = element_blank(),
        axis.line = element_line(),axis.text.y = element_text(angle = 90, hjust = 0.5, vjust = 0.5))

p2+p3


