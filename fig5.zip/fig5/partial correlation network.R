library(dplyr)
library(ppcor)
library(ggplot2)
library(ggraph)
library(tidygraph)
library(scales)
library(RColorBrewer)
library(patchwork)  # 用于图形拼接

setwd("C:\\ondrive备份\\AMD博士课题\\超微型微生物\\分析\\virus\\all_vh\\without_ref\\Manuscript\\final\\revision\\fig5")

data <- read.table("data\\MIP_result.tab", sep = "\t",header = TRUE,stringsAsFactors = FALSE, check.names = FALSE)
all_habun = read.csv('data\\2625abun.tab', stringsAsFactors = FALSE, check.names = FALSE,row.names = 1,sep = '\t')
new_data <-  data[grepl("^[0-9]+$", data$V6), ]
new_data$V6 = as.numeric(new_data$V6)


# MIP>=5 & positive correlation
{
  abundance_table <- all_habun
  mag_pairs <- new_data[new_data$V6 > 4, ]
  
  mag_pairs$co_occurrence <- NA
  mag_pairs$pearson_correlation <- NA
  mag_pairs$p_value <- NA
  
  # Pearson
  library(Hmisc)
  for (i in 1:nrow(mag_pairs)) {
    mag1 <- mag_pairs[i, 1]
    mag2 <- mag_pairs[i, 2]
    mag1_abundance <- abundance_table[mag1, ]
    mag2_abundance <- abundance_table[mag2, ]
    co_occurrence <- sum(mag1_abundance > 0 & mag2_abundance > 0) / length(mag1_abundance)
    co_occurrence_indices <- which(mag1_abundance > 0 & mag2_abundance > 0)
    mag1_co_abundance = mag1_abundance
    mag2_co_abundance = mag2_abundance
    #mag1_co_abundance <- mag1_abundance[co_occurrence_indices]
    #mag2_co_abundance <- mag2_abundance[co_occurrence_indices]
    if (length(mag1_co_abundance) > 4) {
      correlation_test <- rcorr(as.numeric(mag1_co_abundance), as.numeric(mag2_co_abundance), type = "pearson")
      pearson_correlation <- correlation_test$r[1, 2]
      p_value <- correlation_test$P[1, 2]
    } else {
      pearson_correlation <- NA
      p_value <- NA
    }
    mag_pairs$co_occurrence[i] <- co_occurrence
    mag_pairs$pearson_correlation[i] <- pearson_correlation
    mag_pairs$p_value[i] <- p_value
  }
  
  na_count <- sum(is.na(mag_pairs$pearson_correlation))
  print(paste("NA:", na_count))
  mag_pairs <- mag_pairs %>%
    filter(!is.na(pearson_correlation))
  #mag_pairs = mag_pairs[mag_pairs$V6 > 6,]
  new_df = mag_pairs[mag_pairs$pearson_correlation > 0 & mag_pairs$p_value < 0.05, ]
}



tax = read.csv("data\\tax_v214.tsv",stringsAsFactors = FALSE, check.names = FALSE, sep = "\t")
tax = tax[,1:4]
species_pairs_annotated <- merge(new_df, tax, by.x = "V1", by.y = "user_genome", all.x = TRUE)
species_pairs_annotated <- merge(species_pairs_annotated, tax, by.x = "V2", by.y = "user_genome", all.x = TRUE, suffixes = c("_V1", "_V2"))
dsr_list <- read.table("data\\SRM.CSV", sep = ",")
dsr_list$clade='SRM'
species_pairs_annotated2 <- merge(species_pairs_annotated, dsr_list, by.x = "V2", by.y = "V1", all.x = TRUE, suffixes = c("_V1", "_V2"))
species_pairs_annotated2 <- species_pairs_annotated2 %>%
  filter(Domain_V1 == Domain_V2 | (is.na(Domain_V1) & is.na(Domain_V2)))
# 1. 统计每个寄生基因组(V1)对应的宿主基因组(V2)数量
host_counts <- species_pairs_annotated2 %>%
  group_by(V1) %>%
  summarise(host_count = n_distinct(V2))  # 计算每个V1对应的唯一V2数量
# 绘制宿主基因组数量分布直方图
ggplot(host_counts, aes(x = host_count)) +
  geom_histogram(binwidth = 1, fill = "skyblue", color = "black", alpha = 0.7) +
  labs(title = "宿主基因组数量分布",
       x = "宿主基因组数量",
       y = "寄生基因组数量") +
  theme_minimal()
# 2. 统计每个寄生基因组对应的宿主门水平种类数量
phylum_counts <- species_pairs_annotated2 %>%
  group_by(V1) %>%
  summarise(phylum_count = n_distinct(phylum_V2))  # 计算每个V1对应的唯一门数量
# 绘制宿主门水平种类分布直方图
ggplot(phylum_counts, aes(x = phylum_count)) +
  geom_histogram(binwidth = 1, fill = "salmon", color = "black", alpha = 0.7) +
  labs(title = "宿主门水平种类分布",
       x = "宿主门种类数量",
       y = "寄生基因组数量") +
  theme_minimal()


# 只保留1个门
# 保留每个基因组MIP最高的记录
mip_dedup_by_genome <- species_pairs_annotated2 %>%
  group_by(V1) %>%  # 按每个基因组分组
  slice_max(order_by = V6, n = 1, with_ties = FALSE) %>%  # 每组保留MIP最高的记录
  ungroup()

# 保留每个基因组相关性最高的记录
corr_dedup_by_genome <- species_pairs_annotated2 %>%
  group_by(V1) %>%  # 按每个基因组分组
  slice_max(order_by = pearson_correlation, n = 1, with_ties = FALSE) %>%  # 每组保留相关性最高的记录
  ungroup()
# 步骤3: 筛选原始数据
filtered_data <- rbind(mip_dedup_by_genome, corr_dedup_by_genome)

# 保留每个基因组对中相关性最高的记录
#filtered_data <- filtered_data %>%
#  mutate(pair_id = paste(pmin(V1, V2), pmax(V1, V2), sep = "|")) %>%
#  group_by(V1) %>%
#  slice_max(order_by = pearson_correlation, n = 5, with_ties = FALSE) %>%
#  ungroup() %>%
#  dplyr::select(-pair_id)

#HGT
hgt_data = read.csv("data\\HGT.tsv",stringsAsFactors = FALSE, check.names = FALSE, sep = "\t")
# 创建配对ID的函数
create_pair_id <- function(a, b) {
  sorted_pair <- sort(c(a, b))
  paste(sorted_pair, collapse = "|")
}
# 为HGT数据添加配对ID
hgt_data$pair_id <- mapply(create_pair_id, hgt_data$bin_1, hgt_data$bin_2)
# 统计每个配对的HGT事件数量
hgt_counts <- as.data.frame(table(hgt_data$pair_id))
names(hgt_counts) <- c("pair_id", "HGT_count")
# 为mip_dedup添加配对ID
species_pairs_annotated2$pair_id <- mapply(create_pair_id, species_pairs_annotated2$V1, species_pairs_annotated2$V2)
# 合并HGT信息
sy_hgt <- merge(species_pairs_annotated2, hgt_counts, by = "pair_id", all.x = TRUE)
# 添加HGT_exists列并处理NA值
sy_hgt$HGT_exists <- !is.na(sy_hgt$HGT_count)
sy_hgt$HGT_count[is.na(sy_hgt$HGT_count)] <- 0
# 移除临时列
sy_hgt$pair_id <- NULL
sy_hgt = subset(sy_hgt, HGT_exists == 'TRUE')
#sy_hgt$HGT_exists = NULL
#sy_hgt$HGT_count = NULL
#newdedup$pair_id = NULL
newdedup=filtered_data
newdedup$pair_id <- mapply(create_pair_id, newdedup$V1, newdedup$V2)
newdedup <- merge(newdedup, hgt_counts, by = "pair_id", all.x = TRUE)
newdedup$HGT_exists <- !is.na(newdedup$HGT_count)
newdedup$HGT_count[is.na(newdedup$HGT_count)] <- 0
# 移除临时列
newdedup$pair_id <- NULL

final_df = rbind(newdedup,sy_hgt)
dedup_data <- final_df %>%
  # 创建规范化的基因组对ID（不考虑顺序）
  mutate(pair_id = paste(pmin(V1, V2), pmax(V1, V2), sep = "|")) %>%
  # 按规范化ID去重
  distinct(pair_id, .keep_all = TRUE) %>%
  # 移除临时列
  dplyr::select(-pair_id)
# 1. 统计每个寄生基因组(V1)对应的宿主基因组(V2)数量
host_counts <- dedup_data %>%
  group_by(V1) %>%
  summarise(host_count = n_distinct(V2))  # 计算每个V1对应的唯一V2数量
# 绘制宿主基因组数量分布直方图
ggplot(host_counts, aes(x = host_count)) +
  geom_histogram(binwidth = 1, fill = "skyblue", color = "black", alpha = 0.7) +
  labs(title = "宿主基因组数量分布",
       x = "宿主基因组数量",
       y = "寄生基因组数量") +
  theme_minimal()
# 2. 统计每个寄生基因组对应的宿主门水平种类数量
phylum_counts <- dedup_data %>%
  group_by(V1) %>%
  summarise(phylum_count = n_distinct(phylum_V2))  # 计算每个V1对应的唯一门数量
# 绘制宿主门水平种类分布直方图
ggplot(phylum_counts, aes(x = phylum_count)) +
  geom_histogram(binwidth = 1, fill = "salmon", color = "black", alpha = 0.7) +
  labs(title = "宿主门水平种类分布",
       x = "宿主门种类数量",
       y = "寄生基因组数量") +
  theme_minimal()


#write.csv(dedup_data, "data\\symbiotic_host_result_final2.csv", row.names = FALSE)


species_pairs_annotated2 = dedup_data
filtered_B <- all_habun[dedup_data$V2, ]
filtered_B = unique(filtered_B)
dabun = read.csv('data\\DPANN_abun.tab', stringsAsFactors = FALSE, check.names = FALSE,row.names = 1,sep = '\t')
dlist = row.names(dabun)
cabun = read.csv('data\\CPR_abun.tab', stringsAsFactors = FALSE, check.names = FALSE,row.names = 1,sep = '\t')
clist = row.names(cabun)
dmip = unique(species_pairs_annotated2[species_pairs_annotated2$V1 %in% dlist,])
#nrow(dmip[dmip$pearson_correlation > 0 & dmip$p_value < 0.05, ])
cmip = unique(species_pairs_annotated2[species_pairs_annotated2$V1 %in% clist,])
#nrow(cmip[cmip$pearson_correlation > 0 & cmip$p_value < 0.05, ])
# abundance of symbiotic host (SH)
dsymabun = unique(all_habun[dmip$V2, ])
csymabun = unique(all_habun[cmip$V2, ])
# viral abundance
dvabun = read.csv('data\\DPANN_relate_vir_abun.tab', stringsAsFactors = FALSE, check.names = FALSE,row.names = 1,sep = '\t')
cvabun = read.csv('data\\CPR_relate_vir_abun.tab', stringsAsFactors = FALSE, check.names = FALSE,row.names = 1,sep = '\t')
# SH and DPANN/CPR
dsallabun=rbind(dabun,dsymabun)
csallabun=rbind(cabun,csymabun)

# sum abundance cor
dallabun = read.csv('data\\DPANN_all_abun.tab', stringsAsFactors = FALSE, check.names = FALSE,row.names = 1,sep = '\t')
callabun = read.csv('data\\CPR_all_abun.tab', stringsAsFactors = FALSE, check.names = FALSE,row.names = 1,sep = '\t')
factordata<-read.table('data\\metadata.tab',header = T,row.names = 1,check.names = FALSE)


allmip = rbind(cmip,dmip)
vhtab = read.csv('data\\vh.tab', stringsAsFactors = FALSE, check.names = FALSE,sep = '\t')
avabun = rbind(dvabun,cvabun)





# 在偏相关计算前添加病毒丰度过滤
library(tidyverse)
library(ppcor)
library(igraph)

# 初始化存储结果的列表
all_associations <- list()
node_info <- list()

# 定义MAG列表
#HGT related
mag_list <- unique(sy_hgt$V1)
# all
mag_list <- unique(allmip$V1)


#EI
if (!require(corpcor)) {
  install.packages("corpcor")
  library(corpcor)
}
if (!require(fdrtool)) {
  install.packages("fdrtool")
  library(fdrtool)
}
if (!require(tidygraph)) {
  install.packages("tidygraph")
  library(tidygraph)
}
if (!require(ggraph)) {
  install.packages("ggraph")
  library(ggraph)
}



# 初始化存储结果的列表
all_associations <- list()
node_info <- list()

# 设置最小边数阈值
min_edges_threshold <- 10  # 可以根据实际情况调整

for (mag_id in mag_list) {
  tryCatch({
    # 获取当前MAG的关联信息
    mip_one <- allmip[allmip$V1 == mag_id, ]
    vhone <- vhtab[vhtab$Rep_mag == mag_id, ]
    
    # 获取MAG丰度
    mag_abundance <- all_habun[rownames(all_habun) == mag_id,]
    
    # 提取宿主和病毒丰度
    host_abun <- all_habun[rownames(all_habun) %in% mip_one$V2,]
    virus_abun <- avabun[rownames(avabun) %in% vhone$Rep_virus,]
    
    # 跳过没有宿主或病毒关联的MAG
    if (nrow(host_abun) == 0 || nrow(virus_abun) == 0) {
      message(paste("跳过MAG", mag_id, ": 没有找到宿主或病毒关联"))
      next
    }
    
    # 构建宿主-病毒丰度矩阵
    hv_data <- rbind(mag_abundance, host_abun, virus_abun)
    
    # 转置为样本×微生物格式
    transposed_data <- as.data.frame(t(hv_data))
    
    # 移除方差为零的变量（常数变量）
    transposed_data <- transposed_data[, apply(transposed_data, 2, var, na.rm = TRUE) != 0]
    
    # 检查剩余变量数量
    if (ncol(transposed_data) < 2) {
      message(paste("跳过MAG", mag_id, ": 变量数量不足"))
      next
    }
    
    # 计算可能的边数
    n_vars <- ncol(transposed_data)
    possible_edges <- n_vars * (n_vars - 1) / 2
    
    # 确保数据有行名和列名
    if (is.null(colnames(transposed_data)) || length(colnames(transposed_data)) < 2) {
      message(paste("跳过MAG", mag_id, ": 列名不足"))
      next
    }
    
    npn_data <- as.matrix(transposed_data)
    
    if (possible_edges <= min_edges_threshold) {
      pcor_result <- pcor.shrink(npn_data, lambda = 0, verbose = FALSE)
    } else {
      pcor_result <- pcor.shrink(npn_data, verbose = FALSE)
    }
    
    # 设置行列名
    rownames(pcor_result) <- colnames(pcor_result) <- colnames(transposed_data)
    
    # 获取收缩强度λ
    lambda_attr <- attr(pcor_result, "lambda")
    
    # 提取下三角部分的偏相关系数（不包括对角线）
    pcor_vector <- pcor_result[lower.tri(pcor_result)]
    
    # 使用fdrtool估计局部错误发现率
    fdr_result <- tryCatch({
      fdrtool(pcor_vector, statistic = "correlation", plot = FALSE, verbose = FALSE)
    }, error = function(e) {
      message(paste("MAG", mag_id, "的FDR计算出错:", e$message))
      return(NULL)
    })
    
    # 如果FDR计算失败，跳过当前MAG
    if (is.null(fdr_result)) next
    
    # 计算后验概率 (1 - 局部FDR)
    posterior_prob <- 1 - fdr_result$lfdr
    
    # 创建后验概率矩阵
    postprob_matrix <- matrix(NA, nrow = nrow(pcor_result), ncol = ncol(pcor_result))
    postprob_matrix[lower.tri(postprob_matrix)] <- posterior_prob
    postprob_matrix[upper.tri(postprob_matrix)] <- t(postprob_matrix)[upper.tri(postprob_matrix)]
    diag(postprob_matrix) <- 1
    
    # 设置行列名
    rownames(postprob_matrix) <- colnames(postprob_matrix) <- colnames(transposed_data)
    
    # 提取宿主-病毒相关性
    for (host in rownames(host_abun)) {
      for (virus in rownames(virus_abun)) {
        # 确保宿主和病毒在矩阵中存在
        if (!host %in% colnames(postprob_matrix) || !virus %in% colnames(postprob_matrix)) next
        
        # 获取偏相关系数和后验概率
        pcor_value <- pcor_result[host, virus]
        post_prob <- postprob_matrix[host, virus]
        
        # 只保留后验概率 > 0.8 的显著边
        if (!is.na(post_prob) && post_prob > 0.95) {
          # 创建唯一的宿主-病毒对标识符
          pair_id <- paste(sort(c(host, virus)), collapse = "_")
          
          # 存储边信息
          all_associations[[paste0(mag_id, "_", pair_id)]] <- data.frame(
            from = host,
            to = virus,
            r = pcor_value, 
            posterior_prob = post_prob,
            lfdr = 1 - post_prob, # 局部错误发现率
            lambda = lambda_attr,
            mag = mag_id,
            pair_id = pair_id
          )
          
          # 存储节点信息
          if (!host %in% names(node_info)) {
            node_info[[host]] <- data.frame(
              name = host,
              type = "Host",
              degree = 0,
              n_mag = 0
            )
          }
          if (!virus %in% names(node_info)) {
            node_info[[virus]] <- data.frame(
              name = virus,
              type = "Virus",
              degree = 0,
              n_mag = 0
            )
          }
        }
      }
    }
    
    # 清理当前循环中的大对象
    rm(mip_one, vhone, mag_abundance, host_abun, virus_abun, hv_data, 
       transposed_data, npn_data, pcor_result, fdr_result, postprob_matrix)
    
    # 每处理10个MAG强制垃圾回收一次
    if (which(mag_list == mag_id) %% 10 == 0) {
      gc()
    }
    
  }, error = function(e) {
    message(paste("处理MAG时出错:", mag_id, "错误信息:", e$message))
    # 打印更多调试信息
    if (exists("n_vars")) message(paste("变量数量:", n_vars))
    if (exists("transposed_data")) message(paste("数据维度:", dim(transposed_data)))
  })
}

# 生成网络对象用于可视化
if (length(all_associations) > 0) {
  # 创建边列表
  edges_df <- do.call(rbind, all_associations)
  
  # 创建节点列表
  nodes_df <- do.call(rbind, node_info)
  nodes_df$id <- rownames(nodes_df)

}

# 创建tidygraph网络对象
network_graph <- tbl_graph(
  nodes = nodes_df,
  edges = edges_df,
  directed = FALSE
)

library(scales)
library(RColorBrewer)


network_graph <- network_graph %>%
  activate(nodes) %>%
  mutate(
    degree = centrality_degree(),
    betweenness = centrality_betweenness(),
    closeness = centrality_closeness(),
    eigen_centrality = centrality_eigen()
  )

# 设置颜色
node_colors <- c("Host" = "#2E8B57", "Virus" = "#CDBE70")
edge_colors <- c("Positive" = "indianred", "Negative" = "steelblue")

# 确定合适的分隔点和标签
degree_breaks <- pretty(nodes_df$degree, n = 4)  # 创建4个合理的分隔点
degree_labels <- as.character(degree_breaks)     # 创建对应的标签

# 创建网络可视化
network_plot <- ggraph(network_graph, layout = "fr") +
  # 绘制边
  geom_edge_link(
    aes(
      width = abs(r),
      color = ifelse(r > 0, "Positive", "Negative")
    ),
    show.legend = TRUE,
    alpha = 0.5
  ) +
  # 绘制节点
  geom_node_point(
    aes(
      color = type,
      fill = type,
      shape = type
    ),
    size = 5,
    stroke = 0.5,
    show.legend = TRUE
  ) +
  scale_shape_manual(
    name = "Node type",
    values = c("Host" = 16, "Virus" = 17)   # 例如，Host用圆形，Virus用三角
  )+
  # 添加节点标签（只显示高度连接的节点）
  geom_node_label(
    aes(
      label = ifelse(name %in% sy_hgt$V2, name, "")
    ),
    repel = TRUE,
    size = 5,
    alpha = 0.8,
    max.overlaps = 30,
    show.legend = FALSE
  ) +
  # 设置比例尺 - 修复了breaks和labels长度不一致的问题
  scale_size_continuous(
    name = "Degree",
    range = c(3, 10),
    breaks = degree_breaks,      # 使用计算得到的分隔点
    labels = degree_labels       # 使用计算得到的标签
  ) +
  scale_edge_width_continuous(
    name = "|Partial correlation|",
    range = c(1, 3),
    breaks = c(0.2, 0.4, 0.6, 0.8),
    labels = c("0.2", "0.4", "0.6", "0.8")
  ) +
  scale_edge_color_manual(
    name = "Correlation",
    values = edge_colors,
    labels = c("Positive", "Negative")
  ) +
  scale_color_manual(
    name = "Node type",
    values = node_colors
  ) +
  scale_fill_manual(
    name = "Node type",
    values = alpha(node_colors, 0.6)
  ) +
  # 添加图标题和说明
  #labs(
  #  title = "Host-Virus Association Network",
  #  subtitle = paste("Based on partial correlation analysis of", length(unique(edges_df$mag)), "MAGs")) +
  # 调整主题
  theme(
    plot.title = element_text(face = "bold", hjust = 0.5),
    plot.subtitle = element_text(hjust = 0.5),
    legend.position = "bottom",
    legend.box = "vertical",
    legend.key.width = unit(1, "cm"),
    panel.grid = element_blank(),
    axis.title = element_blank(),
    axis.text = element_blank(),
    axis.ticks = element_blank()
  )

# 显示图形
print(network_plot)




# 2. 统计正负边数量
edge_counts <- edges_df %>%
  mutate(correlation_type = ifelse(r > 0, "Positive", "Negative")) %>%
  count(correlation_type) %>%
  right_join(data.frame(correlation_type = c("Positive", "Negative")), by = "correlation_type") %>%
  mutate(n = ifelse(is.na(n), 0, n))

# 创建正负边数量柱状图
bar_plot <- ggplot(edge_counts, aes(x = correlation_type, y = n, fill = correlation_type)) +
  geom_col(show.legend = FALSE) +
  geom_text(aes(label = n), vjust = -0.5, size = 5) +
  scale_fill_manual(values = c("Positive" = "#E41A1C", "Negative" = "#377EB8")) +
  labs(
    y = "Count"
  ) +
  theme_bw(base_size = 14) +
  theme(
    plot.title = element_text(face = "bold", hjust = 0.5),
    panel.border = element_blank(),
    panel.grid = element_blank(),
    axis.text = element_text(size = 12),
    axis.line = element_line()
  )

# 3. 创建相关性系数绝对值箱线图
edges_df$correlation_type <- ifelse(edges_df$r > 0, "Positive", "Negative")
box_plot <- ggplot(edges_df, aes(y = abs(r), x = correlation_type, color = correlation_type)) +
  geom_boxplot() +
  geom_jitter() +
  labs(
    y = "Partial Correlation",
  ) +
  scale_fill_manual(values = c("Positive" = "#E41A1C", "Negative" = "#377EB8")) +
  theme_bw(base_size = 14) +
  theme(
    plot.title = element_text(face = "bold", hjust = 0.5),
    panel.border = element_blank(),
    panel.grid = element_blank(),
    axis.text.y = element_text(size = 12),
    axis.line = element_line()
  )

# 4. 使用patchwork拼接图形
combined_plot <- network_plot / (bar_plot + box_plot) +
  plot_layout(heights = c(3, 1))  # 网络图占3份高度，下面的图占1份高度

# 显示组合图形
print(combined_plot)
#12.5*10

