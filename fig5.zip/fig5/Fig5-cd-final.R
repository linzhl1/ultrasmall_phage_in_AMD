library(dplyr)
library(ppcor)
library(ggplot2)

setwd("C:\\ondrive备份\\AMD博士课题\\超微型微生物\\分析\\virus\\all_vh\\without_ref\\Manuscript\\final\\revision\\fig5")

data <- read.table("data\\MIP_result.tab", sep = "\t",header = TRUE,stringsAsFactors = FALSE, check.names = FALSE)
all_habun = read.csv('data\\2625abun.tab', stringsAsFactors = FALSE, check.names = FALSE,row.names = 1,sep = '\t')
new_data <-  data[grepl("^[0-9]+$", data$V6), ]
new_data$V6 = as.numeric(new_data$V6)


# MIP>=5 & positive correlation
{
  abundance_table <- all_habun
  mag_pairs <- new_data[new_data$V6 > 4, ]
  
  mag_pairs$co_occurrence <- NA
  mag_pairs$pearson_correlation <- NA
  mag_pairs$p_value <- NA
  
  # Pearson
  library(Hmisc)
  for (i in 1:nrow(mag_pairs)) {
    mag1 <- mag_pairs[i, 1]
    mag2 <- mag_pairs[i, 2]
    mag1_abundance <- abundance_table[mag1, ]
    mag2_abundance <- abundance_table[mag2, ]
    co_occurrence <- sum(mag1_abundance > 0 & mag2_abundance > 0) / length(mag1_abundance)
    co_occurrence_indices <- which(mag1_abundance > 0 & mag2_abundance > 0)
    mag1_co_abundance = mag1_abundance
    mag2_co_abundance = mag2_abundance
    #mag1_co_abundance <- mag1_abundance[co_occurrence_indices]
    #mag2_co_abundance <- mag2_abundance[co_occurrence_indices]
    if (length(mag1_co_abundance) > 4) {
      correlation_test <- rcorr(as.numeric(mag1_co_abundance), as.numeric(mag2_co_abundance), type = "pearson")
      pearson_correlation <- correlation_test$r[1, 2]
      p_value <- correlation_test$P[1, 2]
    } else {
      pearson_correlation <- NA
      p_value <- NA
    }
    mag_pairs$co_occurrence[i] <- co_occurrence
    mag_pairs$pearson_correlation[i] <- pearson_correlation
    mag_pairs$p_value[i] <- p_value
  }
  
  na_count <- sum(is.na(mag_pairs$pearson_correlation))
  print(paste("NA:", na_count))
  mag_pairs <- mag_pairs %>%
    filter(!is.na(pearson_correlation))
  #mag_pairs = mag_pairs[mag_pairs$V6 > 6,]
  new_df = mag_pairs[mag_pairs$pearson_correlation > 0 & mag_pairs$p_value < 0.05, ]
}



tax = read.csv("data\\tax_v214.tsv",stringsAsFactors = FALSE, check.names = FALSE, sep = "\t")
tax = tax[,1:4]
species_pairs_annotated <- merge(new_df, tax, by.x = "V1", by.y = "user_genome", all.x = TRUE)
species_pairs_annotated <- merge(species_pairs_annotated, tax, by.x = "V2", by.y = "user_genome", all.x = TRUE, suffixes = c("_V1", "_V2"))
dsr_list <- read.table("data\\SRM.CSV", sep = ",")
dsr_list$clade='SRM'
species_pairs_annotated2 <- merge(species_pairs_annotated, dsr_list, by.x = "V2", by.y = "V1", all.x = TRUE, suffixes = c("_V1", "_V2"))
species_pairs_annotated2 <- species_pairs_annotated2 %>%
  filter(Domain_V1 == Domain_V2 | (is.na(Domain_V1) & is.na(Domain_V2)))
# 1. 统计每个寄生基因组(V1)对应的宿主基因组(V2)数量
host_counts <- species_pairs_annotated2 %>%
  group_by(V1) %>%
  summarise(host_count = n_distinct(V2))  # 计算每个V1对应的唯一V2数量
# 绘制宿主基因组数量分布直方图
ggplot(host_counts, aes(x = host_count)) +
  geom_histogram(binwidth = 1, fill = "skyblue", color = "black", alpha = 0.7) +
  labs(title = "宿主基因组数量分布",
       x = "宿主基因组数量",
       y = "寄生基因组数量") +
  theme_minimal()
# 2. 统计每个寄生基因组对应的宿主门水平种类数量
phylum_counts <- species_pairs_annotated2 %>%
  group_by(V1) %>%
  summarise(phylum_count = n_distinct(phylum_V2))  # 计算每个V1对应的唯一门数量
# 绘制宿主门水平种类分布直方图
ggplot(phylum_counts, aes(x = phylum_count)) +
  geom_histogram(binwidth = 1, fill = "salmon", color = "black", alpha = 0.7) +
  labs(title = "宿主门水平种类分布",
       x = "宿主门种类数量",
       y = "寄生基因组数量") +
  theme_minimal()


# 只保留1个门
# 保留每个基因组MIP最高的记录
mip_dedup_by_genome <- species_pairs_annotated2 %>%
  group_by(V1) %>%  # 按每个基因组分组
  slice_max(order_by = V6, n = 1, with_ties = FALSE) %>%  # 每组保留MIP最高的记录
  ungroup()

# 保留每个基因组相关性最高的记录
corr_dedup_by_genome <- species_pairs_annotated2 %>%
  group_by(V1) %>%  # 按每个基因组分组
  slice_max(order_by = pearson_correlation, n = 1, with_ties = FALSE) %>%  # 每组保留相关性最高的记录
  ungroup()
# 步骤3: 筛选原始数据
filtered_data <- rbind(mip_dedup_by_genome, corr_dedup_by_genome)

# 保留每个基因组对中相关性最高的记录
#filtered_data <- filtered_data %>%
#  mutate(pair_id = paste(pmin(V1, V2), pmax(V1, V2), sep = "|")) %>%
#  group_by(V1) %>%
#  slice_max(order_by = pearson_correlation, n = 5, with_ties = FALSE) %>%
#  ungroup() %>%
#  dplyr::select(-pair_id)

#HGT
hgt_data = read.csv("data\\HGT.tsv",stringsAsFactors = FALSE, check.names = FALSE, sep = "\t")
# 创建配对ID的函数
create_pair_id <- function(a, b) {
  sorted_pair <- sort(c(a, b))
  paste(sorted_pair, collapse = "|")
}
# 为HGT数据添加配对ID
hgt_data$pair_id <- mapply(create_pair_id, hgt_data$bin_1, hgt_data$bin_2)
# 统计每个配对的HGT事件数量
hgt_counts <- as.data.frame(table(hgt_data$pair_id))
names(hgt_counts) <- c("pair_id", "HGT_count")
# 为mip_dedup添加配对ID
species_pairs_annotated2$pair_id <- mapply(create_pair_id, species_pairs_annotated2$V1, species_pairs_annotated2$V2)
# 合并HGT信息
sy_hgt <- merge(species_pairs_annotated2, hgt_counts, by = "pair_id", all.x = TRUE)
# 添加HGT_exists列并处理NA值
sy_hgt$HGT_exists <- !is.na(sy_hgt$HGT_count)
sy_hgt$HGT_count[is.na(sy_hgt$HGT_count)] <- 0
# 移除临时列
sy_hgt$pair_id <- NULL
sy_hgt = subset(sy_hgt, HGT_exists == 'TRUE')
#sy_hgt$HGT_exists = NULL
#sy_hgt$HGT_count = NULL
#newdedup$pair_id = NULL
newdedup=filtered_data
newdedup$pair_id <- mapply(create_pair_id, newdedup$V1, newdedup$V2)
newdedup <- merge(newdedup, hgt_counts, by = "pair_id", all.x = TRUE)
newdedup$HGT_exists <- !is.na(newdedup$HGT_count)
newdedup$HGT_count[is.na(newdedup$HGT_count)] <- 0
# 移除临时列
newdedup$pair_id <- NULL

final_df = rbind(newdedup,sy_hgt)
dedup_data <- final_df %>%
  # 创建规范化的基因组对ID（不考虑顺序）
  mutate(pair_id = paste(pmin(V1, V2), pmax(V1, V2), sep = "|")) %>%
  # 按规范化ID去重
  distinct(pair_id, .keep_all = TRUE) %>%
  # 移除临时列
  dplyr::select(-pair_id)
# 1. 统计每个寄生基因组(V1)对应的宿主基因组(V2)数量
host_counts <- dedup_data %>%
  group_by(V1) %>%
  summarise(host_count = n_distinct(V2))  # 计算每个V1对应的唯一V2数量
# 绘制宿主基因组数量分布直方图
n1=ggplot(host_counts, aes(x = host_count)) +
  geom_histogram(binwidth = 1, fill = "skyblue", color = "black", alpha = 0.7) +
  labs(
       x = "SH genome number",
       y = "CPR/DPANN genome number") +
  theme_classic()
# 2. 统计每个寄生基因组对应的宿主门水平种类数量
phylum_counts <- dedup_data %>%
  group_by(V1) %>%
  summarise(phylum_count = n_distinct(phylum_V2))  # 计算每个V1对应的唯一门数量
# 绘制宿主门水平种类分布直方图
n2=ggplot(phylum_counts, aes(x = phylum_count)) +
  geom_histogram(binwidth = 1, fill = "salmon", color = "black", alpha = 0.7) +
  labs(
    x = "SH phylum number",
    y = "CPR/DPANN genome number") +
  theme_classic()
n1+n2


#write.csv(dedup_data, "data\\symbiotic_host_result_final2.csv", row.names = FALSE)


species_pairs_annotated2 = dedup_data
filtered_B <- all_habun[dedup_data$V2, ]
filtered_B = unique(filtered_B)
dabun = read.csv('data\\DPANN_abun.tab', stringsAsFactors = FALSE, check.names = FALSE,row.names = 1,sep = '\t')
dlist = row.names(dabun)
cabun = read.csv('data\\CPR_abun.tab', stringsAsFactors = FALSE, check.names = FALSE,row.names = 1,sep = '\t')
clist = row.names(cabun)
dmip = unique(species_pairs_annotated2[species_pairs_annotated2$V1 %in% dlist,])
#nrow(dmip[dmip$pearson_correlation > 0 & dmip$p_value < 0.05, ])
cmip = unique(species_pairs_annotated2[species_pairs_annotated2$V1 %in% clist,])
#nrow(cmip[cmip$pearson_correlation > 0 & cmip$p_value < 0.05, ])
# abundance of symbiotic host (SH)
dsymabun = unique(all_habun[dmip$V2, ])
csymabun = unique(all_habun[cmip$V2, ])
# viral abundance
dvabun = read.csv('data\\DPANN_relate_vir_abun.tab', stringsAsFactors = FALSE, check.names = FALSE,row.names = 1,sep = '\t')
cvabun = read.csv('data\\CPR_relate_vir_abun.tab', stringsAsFactors = FALSE, check.names = FALSE,row.names = 1,sep = '\t')
# SH and DPANN/CPR
dsallabun=rbind(dabun,dsymabun)
csallabun=rbind(cabun,csymabun)

# sum abundance cor
dallabun = read.csv('data\\DPANN_all_abun.tab', stringsAsFactors = FALSE, check.names = FALSE,row.names = 1,sep = '\t')
callabun = read.csv('data\\CPR_all_abun.tab', stringsAsFactors = FALSE, check.names = FALSE,row.names = 1,sep = '\t')
factordata<-read.table('data\\metadata.tab',header = T,row.names = 1,check.names = FALSE)
cor.test(colSums(dsymabun),colSums(dabun))
cor.test(colSums(csymabun),colSums(cabun))

#mantel
library(vegan)
dist.dv<-vegdist(decostand(t(dvabun),method='total'),method = 'bray')
dist.cv<-vegdist(decostand(t(cvabun),method='total'),method = 'bray')
dist.dh<-vegdist(decostand(t(dabun),method='total'),method = 'bray')
dist.ch<-vegdist(decostand(t(cabun),method='total'),method = 'bray')
vegan::mantel(dist.dv, dist.dh, method = 'pearson', permutations = 999, na.rm = TRUE)
vegan::mantel(dist.cv, dist.ch, method = 'pearson', permutations = 999, na.rm = TRUE)

#partial mantel
dist.dmip=vegdist(decostand(t(dsymabun),method='total'),method = 'bray')
dist.cmip=vegdist(decostand(t(csymabun),method='total'),method = 'bray')
vegan::mantel.partial(dist.dv, dist.dh, dist.dmip, method = 'pearson', permutations = 999, na.rm = TRUE)
vegan::mantel.partial(dist.dv, dist.dmip, dist.dh, method = 'pearson', permutations = 999, na.rm = TRUE)
vegan::mantel(dist.dv, dist.dmip, method = 'pearson', permutations = 999, na.rm = TRUE)
vegan::mantel.partial(dist.cv, dist.ch, dist.cmip, method = 'pearson', permutations = 999, na.rm = TRUE)
vegan::mantel.partial(dist.cv, dist.cmip, dist.ch, method = 'pearson', permutations = 999, na.rm = TRUE)
vegan::mantel(dist.cv, dist.cmip, method = 'pearson', permutations = 999, na.rm = TRUE)

#SRM
dsr_mipd = dmip[dmip$V2 %in% dsr_list$V1,]
dsr_mipc = cmip[cmip$V2 %in% dsr_list$V1,]
dsr_mipdmabun = unique(all_habun[dsr_mipd$V2, ])
dsr_mipcmabun = unique(all_habun[dsr_mipc$V2, ])
dist.dsrd = vegdist(decostand(t(dsr_mipdmabun),method='total'),method = 'bray')
dist.dsrc = vegdist(decostand(t(dsr_mipcmabun),method='total'),method = 'bray')
vegan::mantel(dist.dv, dist.dsrd, method = 'pearson', permutations = 999, na.rm = TRUE)
vegan::mantel.partial(dist.dv, dist.dsrd, dist.dh, method = 'pearson', permutations = 999, na.rm = TRUE)
vegan::mantel(dist.cv, dist.dsrc, method = 'pearson', permutations = 999, na.rm = TRUE)
vegan::mantel.partial(dist.cv, dist.dsrc, dist.ch, method = 'pearson', permutations = 999, na.rm = TRUE)


#case study of YP2.bin58
library(ppcor)
mip_YP2.bin58 = dmip[dmip$V1 %in% 'YP2.bin58',]
selected_rows <- subset(all_habun, rownames(all_habun) %in% mip_YP2.bin58$V2)
sumabun=colSums(selected_rows)
cordata=data.frame(virus=dvabun[rownames(dvabun) %in% c("YP4_provirus51"), ],symbiont=sumabun)
cor.test(unlist(as.list(dvabun[rownames(dvabun) %in% c("YP4_provirus51"), ])),sumabun)
syhost=as.data.frame(t(selected_rows))
#syhost = syhost[, !names(syhost) %in% c("MAS3.bin23", "FK3.bin10", "YP2.bin31")]
syhost$virus=unlist(as.list(dvabun[rownames(dvabun) %in% c("YP4_provirus51"), ]))
syhost$all_sy = sumabun
syhost$DPANN=as.data.frame(t(all_habun))$YP2.bin58
cor.test(syhost$virus,syhost$DPANN)
cor.test(syhost$virus,syhost$all_sy)
pcor.test(syhost$all_sy,syhost$virus,syhost$DPANN)
syhost_v0 <- syhost[syhost$virus > 0, ]
syhost_v0 <- syhost_v0[syhost_v0$DPANN > 0, ]
syhost_v0 <- syhost_v0[syhost_v0$all_sy > 0, ]
syhost <- syhost_v0
#syhost = as.data.frame(t(scale(t(syhost))))
#IQR
{
  # virus IQR
  virus_Q1 <- quantile(syhost$virus, 0.25, na.rm = TRUE)
  virus_Q3 <- quantile(syhost$virus, 0.75, na.rm = TRUE)
  virus_IQR <- IQR(syhost$virus, na.rm = TRUE)
  virus_lower <- virus_Q1 - 1.5 * virus_IQR
  virus_upper <- virus_Q3 + 1.5 * virus_IQR
  
  # SH IQR
  all_sy_Q1 <- quantile(syhost$all_sy, 0.25, na.rm = TRUE)
  all_sy_Q3 <- quantile(syhost$all_sy, 0.75, na.rm = TRUE)
  all_sy_IQR <- IQR(syhost$all_sy, na.rm = TRUE)
  all_sy_lower <- all_sy_Q1 - 1.5 * all_sy_IQR
  all_sy_upper <- all_sy_Q3 + 1.5 * all_sy_IQR
  # DPANN IQR
  DPANN_Q1 <- quantile(syhost$DPANN, 0.25, na.rm = TRUE)
  DPANN_Q3 <- quantile(syhost$DPANN, 0.75, na.rm = TRUE)
  DPANN_IQR <- IQR(syhost$DPANN, na.rm = TRUE)
  DPANN_lower <- DPANN_Q1 - 1.5 * DPANN_IQR
  DPANN_upper <- DPANN_Q3 + 1.5 * DPANN_IQR
}
syhost <- syhost %>%
  mutate(
    virus_outlier = virus < quantile(virus, 0.25) - 1.5*IQR(virus) | 
      virus > quantile(virus, 0.75) + 1.5*IQR(virus),
    all_sy_outlier = all_sy < quantile(all_sy, 0.25) - 1.5*IQR(all_sy) | 
      all_sy > quantile(all_sy, 0.75) + 1.5*IQR(all_sy),
    DPANN_outlier = DPANN < quantile(DPANN, 0.25) - 1.5*IQR(DPANN) | 
      DPANN > quantile(DPANN, 0.75) + 1.5*IQR(DPANN),
    is_outlier = virus_outlier | all_sy_outlier | DPANN_outlier
  )


# virus-DPANN host
{
  cor_all <- cor.test(~ virus + DPANN, data = syhost, method = "pearson")
  cor_filtered <- cor.test(~ virus + DPANN, 
                           data = filter(syhost, !virus_outlier), 
                           method = "pearson")
  cor_text <- sprintf("Pearson's R
  Overall: %.2f (p=%.1e)
  Filtered: %.2f (p=%.1e)",
                      cor_all$estimate,
                      cor_all$p.value,
                      cor_filtered$estimate,
                      cor_filtered$p.value)
  p1=ggplot(syhost, aes(x = virus, y = DPANN)) +
    geom_point(aes(color = virus_outlier), size = 3, alpha = 0.8) +
    geom_smooth(
      data = filter(syhost, !virus_outlier),
      method = "lm", 
      se = FALSE, 
      color = "#661d4a",
      formula = y ~ x
    ) +
    geom_smooth(
      data = syhost,
      method = "lm", 
      se = FALSE, 
      color = "#808080",
      formula = y ~ x
    ) +
    annotate("text",
             x = max(syhost$DPANN)*0.5,
             y = max(syhost$virus)*0.6,
             label = cor_text,
             hjust = 1, vjust = 0,
             size = 4.5,
             color = "black") +
    scale_color_manual(
      name = "Data Points",
      values = c("FALSE" = "#661d4a", "TRUE" = "gray50"),
      labels = c("Normal", "Outlier")
    ) +
    labs(
      x = "Viral Abundance",
      y = "PSH Abundance"
    ) +
    theme_bw(base_size = 18) +
    theme(
      legend.position = c(0.2, 0.65))+
    theme(panel.border = element_blank(),
          panel.grid = element_blank(),
          axis.line = element_line(),axis.text.y = element_text(angle = 90, hjust = 0.5, vjust = 0.5))
  p1
}

# virus-PSH
{
  cor_all <- cor.test(~ virus + all_sy, data = syhost, method = "spearman")
  cor_filtered <- cor.test(~ virus + all_sy, 
                           data = filter(syhost, !virus_outlier), 
                           method = "spearman")
  cor_text <- sprintf("Spearman's R
  Overall: %.2f (p=%.1e)
  Filtered: %.2f (p=%.1e)",
                      cor_all$estimate,
                                 cor_all$p.value,
                      cor_filtered$estimate,
                                      cor_filtered$p.value)
  p2=ggplot(syhost, aes(x = virus, y = all_sy)) +
    geom_point(aes(color = virus_outlier), size = 3, alpha = 0.8) +
    geom_smooth(
      data = filter(syhost, !virus_outlier),
      method = "lm", 
      se = FALSE, 
      color = "#661d4a",
      formula = y ~ x
    ) +
    geom_smooth(
      data = syhost,
      method = "lm", 
      se = FALSE, 
      color = "#808080",
      formula = y ~ x
    ) +
    annotate("text",
             x = max(syhost$all_sy)*0.15,
                     y = max(syhost$virus)*0.15,
             label = cor_text,
             hjust = 1, vjust = 0,
             size = 4.5,
             color = "black") +
    scale_color_manual(
      name = "Data Points",
      values = c("FALSE" = "#661d4a", "TRUE" = "gray50"),
      labels = c("Normal", "Outlier")
    ) + ylim(0, 150) +  xlim(0, 150) +
    labs(
      x = "Viral Abundance",
      y = "PSH Abundance"
    ) +
    theme_bw(base_size = 18) +
    theme(
      legend.position = c(0.8, 0.5))+
    theme(panel.border = element_blank(),
          panel.grid = element_blank(),
          axis.line = element_line(),axis.text.y = element_text(angle = 90, hjust = 0.5, vjust = 0.5))
  p2
}


# PSHs availabity
{
  syhost$log10syh_h = log10(syhost$all_sy/syhost$DPANN)
  syhost <- syhost %>% filter_all(all_vars(is.finite(.)))
  cor_all <- cor.test(~ virus + log10syh_h, data = syhost, method = "pearson")
  cor_filtered <- cor.test(~ virus + log10syh_h, 
                           data = filter(syhost, !virus_outlier), 
                           method = "pearson")
  cor_text <- sprintf("Pearson's R
  Overall: %.2f (p=%.1e)
  Filtered: %.2f (p=%.1e)",
                      cor_all$estimate,
                      cor_all$p.value,
                      cor_filtered$estimate,
                      cor_filtered$p.value)
  p3=ggplot(syhost, aes(x = virus, y = log10syh_h)) +
    geom_point(aes(color = virus_outlier), size = 3, alpha = 0.8) +
    geom_smooth(
      data = filter(syhost, !virus_outlier),
      method = "lm", 
      se = FALSE, 
      color = "#661d4a",
      formula = y ~ x
    ) +
    geom_smooth(
      data = syhost,
      method = "lm", 
      se = FALSE, 
      color = "#808080",
      formula = y ~ x
    ) +   xlim(0, 150) +
    annotate("text",
             x = max(syhost$virus)*0.95,
             y = max(syhost$log10syh_h)*0.85,
             label = cor_text,
             hjust = 1, vjust = 0,
             size = 4.5,
             color = "black") +
    scale_color_manual(
      name = "Data Points",
      values = c("FALSE" = "#661d4a", "TRUE" = "gray50"),
      labels = c("Normal", "Outlier")
    ) +
    labs(
      x = "Viral Abundance",
      y = "PSH availabity (PSHs versus DPANN)"
    ) +
    theme_bw(base_size = 18) +
    theme(
      legend.position = c(0.8, 0.5))+
    theme(panel.border = element_blank(),
          panel.grid = element_blank(),
          axis.line = element_line(),axis.text.y = element_text(angle = 90, hjust = 0.5, vjust = 0.5))
  p3
}
#6*6
p1
library(patchwork)
#12.5*5.8
p2+p3
