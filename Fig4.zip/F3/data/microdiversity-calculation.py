import pandas as pd
import random
from pathlib import Path


def bootstrap_mean(values, n_bootstrap=10000, sample_size=100):
    if not values:
        return None
    total = 0.0
    n = len(values)
    for _ in range(n_bootstrap):
        indices = random.choices(range(n), k=sample_size)
        subsample_mean = sum(values[i] for i in indices) / sample_size
        total += subsample_mean
    return total / n_bootstrap


def get_micro(clade, sample_list, pfile, tfile):
    micro_path = f"local_{clade}_microdiversity.tsv"
    micro_tab = pd.read_csv(micro_path, sep="\t")
    fs_list = micro_tab.iloc[:, 2].tolist()
    plist = micro_tab.iloc[:, 3].astype(float).tolist()
    tlist = micro_tab.iloc[:, 6].astype(float).tolist()
    tempp = {sample: [] for sample in sample_list}
    tempt = {sample: [] for sample in sample_list}
    for f, p, t in zip(fs_list, plist, tlist):
        if f in sample_list:
            tempp[f].append(p)
            tempt[f].append(t)
    p_line = [clade]
    t_line = [clade]
    for sample in sample_list:
        # pi
        p_values = tempp[sample]
        p_mean = bootstrap_mean(p_values) if p_values else None
        p_line.append(f"{p_mean:.6f}" if p_mean is not None else "NA")

        # theta
        t_values = tempt[sample]
        t_mean = bootstrap_mean(t_values) if t_values else None
        t_line.append(f"{t_mean:.6f}" if t_mean is not None else "NA")

    # writen
    pfile.write("\t".join(p_line) + "\n")
    tfile.write("\t".join(t_line) + "\n")


if __name__ == "__main__":
    sample_list = pd.read_csv(f'sample.txt', sep="\t", header=None)[0].values.tolist()
    with open(f"p_result.tsv", "w") as p_out, open(f"t_result.tsv", "w") as t_out:
        p_out.write("Clade\t" + "\t".join(sample_list) + "\n")
        t_out.write("Clade\t" + "\t".join(sample_list) + "\n")
        for clade in ["CPR", "DPANN"]:
            get_micro(clade, sample_list, p_out, t_out)
