library(ggplot2)
library(linkET)
library(rfPermute)
library(vegan)
library(patchwork)
library(tidyr)


factordata<-read.table('data\\metadata.tab',header = T,row.names = 1,check.names = FALSE)
{
  dvabun = read.table('data\\DPANN_relate_vir_abun.tab',sep = '\t', stringsAsFactors = FALSE,row.names = 1,header = T,check.names = F)
  cvabun = read.table('data\\CPR_relate_vir_abun.tab',sep = '\t', stringsAsFactors = FALSE,row.names = 1,header = T,check.names = F)
  dabun = read.table('data\\DPANN_abun.tab',sep = '\t', stringsAsFactors = FALSE,row.names = 1,header = T,check.names = F)
  cabun = read.table('data\\CPR_abun.tab',sep = '\t', stringsAsFactors = FALSE,row.names = 1,header = T,check.names = F)
  lifetab = read.table('data\\life.txt',sep = '\t', stringsAsFactors = FALSE,header = T,check.names = F)
  dvabun_virulent = dvabun[rownames(dvabun) %in% lifetab[lifetab$final2 == 'virulent',]$name,]
  dvabun_temp = dvabun[rownames(dvabun) %in% lifetab[lifetab$final2 == 'temperate',]$name,]
  cvabun_virulent = cvabun[rownames(cvabun) %in% lifetab[lifetab$final2 == 'virulent',]$name,]
  cvabun_temp = cvabun[rownames(cvabun) %in% lifetab[lifetab$final2 == 'temperate',]$name,]
  dvabun_virulent = colSums(dvabun_virulent)
  dvabun_temp = colSums(dvabun_temp)
  cvabun_virulent = colSums(cvabun_virulent)
  cvabun_temp = colSums(cvabun_temp)
  life_abun = data.frame(dvabun_virulent,dvabun_temp,cvabun_virulent,cvabun_temp)
  life_abun$cLysogenic_rate = life_abun$cvabun_temp/(cvabun_virulent+cvabun_temp)
  life_abun$dLysogenic_rate = life_abun$dvabun_temp/(dvabun_virulent+dvabun_temp)
  life_abun$cvabun = cvabun_virulent + cvabun_temp
  life_abun$dvabun = dvabun_virulent + dvabun_temp
  life_abun$c_infect = colSums(cabun)/factordata$Chost_abun
  life_abun$d_infect = colSums(dabun)/factordata$Dhost_abun
  life_abun$cabun = factordata$Chost_abun
  life_abun$dabun = factordata$Dhost_abun
  life_abun$cvh = life_abun$cvabun/colSums(cabun)
  life_abun$dvh = life_abun$dvabun/colSums(dabun)
  sysdata = life_abun
}
factordata = factordata[,c(19:32,35:36)]
library('Hmisc')
co_linear <- varclus(as.matrix(factordata), similarity="spear")
co_linear
plot(co_linear)
factordata <- select(factordata,-c(MAP,Zn))
library(dplyr)
factordata = factordata[!is.infinite(rowSums(sysdata)),]
sysdata <- sysdata[!is.infinite(rowSums(sysdata)),]
sysdata$logcvh = log(sysdata$cvh)
sysdata$logdvh = log(sysdata$dvh)
sysdata = sysdata[!factordata$EC > 7 &!factordata$pH < 2, ]
factordata = factordata[!factordata$EC > 7, ]
factordata = factordata[!factordata$pH < 2, ]
factordata = decostand(factordata,method = "standardize")

{
  
  library("leaps")
  library(glmm.hp)
  combine<-cbind(sysdata,factordata)
  #logcvh
  fit<-lm(logcvh~pH+EC+Fe+Ferric+Ferrous+Cu+Mn+Cd+Pb+TOC+Sulfate+TN+TP+MAT,data=combine)
  {
    options(na.action = "na.fail") #To set it up globally first
    dd11<-dredge(fit)
    subset(dd11, delta<2) #show the best models
    best11<-model.avg(dd11, subset = delta < 2)
    summary(best11)
    b11<-lm(logcvh~pH+EC+Ferric,data=combine)
    summary(b11)
    r.squaredGLMM(b11)
    glmm.hp(b11)
    plot(glmm.hp(b11))
    draw = data.frame(glmm.hp(b11)$hierarchical.partitioning)
    draw$value = row.names(draw)
    g1=ggplot(draw, aes(x = reorder(value, -Individual), y = Individual)) +
      geom_bar(stat = "identity") +
      theme_classic() +
      labs(title = "Log10 CPR VHR",x = "Factor", y = "R2.adj")
  }
  summary(fit)
  
  #cLysogenic_rate
  fit<-lm(cLysogenic_rate~pH+EC+Fe+Ferric+Ferrous+Cu+Mn+Cd+Pb+TOC+Sulfate+TN+TP+MAT,data=combine)
  {
    options(na.action = "na.fail") #To set it up globally first
    dd11<-dredge(fit)
    subset(dd11, delta<2) #show the best models
    best11<-model.avg(dd11, subset = delta < 2)
    summary(best11)
    b11<-lm(cLysogenic_rate~EC+Pb+pH+Sulfate+TP+MAT,data=combine)
    summary(b11)
    r.squaredGLMM(b11)
    glmm.hp(b11)
    plot(glmm.hp(b11))
    draw = data.frame(glmm.hp(b11)$hierarchical.partitioning)
    draw$value = row.names(draw)
    g2=ggplot(draw, aes(x = reorder(value, -Individual), y = Individual)) +
      geom_bar(stat = "identity") +
      theme_classic() +
      labs(title = "CPR Lysogenic rate",x = "Factor", y = "R2.adj")
  }
  
  #logdvh
  fit<-lm(logdvh~pH+EC+Fe+Ferric+Ferrous+Cu+Mn+Cd+Pb+TOC+Sulfate+TN+TP+MAT,data=combine)
  summary(fit)
  {
    options(na.action = "na.fail") #To set it up globally first
    dd11<-dredge(fit)
    subset(dd11, delta<2) #show the best models
    best11<-model.avg(dd11, subset = delta < 2)
    summary(best11)
    b11<-lm(logdvh~Fe+EC+Ferrous+MAT+Sulfate+TN+TOC+TP,data=combine)
    summary(b11)
    r.squaredGLMM(b11)
    glmm.hp(b11)
    plot(glmm.hp(b11))
    draw = data.frame(glmm.hp(b11)$hierarchical.partitioning)
    draw$value = row.names(draw)
    g3=ggplot(draw, aes(x = reorder(value, -Individual), y = Individual)) +
      geom_bar(stat = "identity") +
      theme_classic() +
      labs(title = "Log10 DPANN VHR",x = "Factor", y = "R2.adj")
  }
  
  #dLysogenic_rate
  fit<-lm(dLysogenic_rate~pH+EC+Fe+Ferric+Ferrous+Cu+Mn+Cd+Pb+TOC+Sulfate+TN+TP+MAT,data=combine)
  summary(fit)
  {
    options(na.action = "na.fail") #To set it up globally first
    dd11<-dredge(fit)
    subset(dd11, delta<2) #show the best models
    best11<-model.avg(dd11, subset = delta < 2)
    summary(best11)
    b11<-lm(dLysogenic_rate~Fe+EC+Ferrous+TN,data=combine)
    summary(b11)
    r.squaredGLMM(b11)
    glmm.hp(b11)
    plot(glmm.hp(b11))
    draw = data.frame(glmm.hp(b11)$hierarchical.partitioning)
    draw$value = row.names(draw)
    g4=ggplot(draw, aes(x = reorder(value, -Individual), y = Individual)) +
      geom_bar(stat = "identity") +
      theme_classic() +
      labs(title = "DPANN Lysogenic rate",x = "Factor", y = "R2.adj")
  }
}
g1+g2+g3+g4

# variance
combine$vh_var=combine$logcvh-combine$logdvh
#logvh
fit<-lm(vh_var~poly(pH, 2)+EC+Fe+Ferric+Ferrous+Cu+Mn+Cd+Pb+TOC+Sulfate+TN+TP+MAT,data=combine)
{
  options(na.action = "na.fail") #To set it up globally first
  dd11<-dredge(fit)
  subset(dd11, delta<2) #show the best models
  best11<-model.avg(dd11, subset = delta < 2)
  summary(best11)
  b11<-lm(vh_var~Cu+EC+Fe+TN+MAT+TOC,data=combine)
  summary(b11)
  r.squaredGLMM(b11)
  glmm.hp(b11)
  plot(glmm.hp(b11))
  draw = data.frame(glmm.hp(b11)$hierarchical.partitioning)
  draw$value = row.names(draw)
  gvh=ggplot(draw, aes(x = reorder(value, -Individual), y = Individual)) +
    geom_bar(stat = "identity") +
    theme_classic() +
    labs(title = "Log10 VHRs (CPR-DPANN)",x = "Factor", y = "R2.adj")
  gvh
}

#lys
combine$lys=combine$cLysogenic_rate-combine$dLysogenic_rate
fit<-lm(lys~poly(pH, 2)+EC+Fe+Ferric+Ferrous+Cu+Mn+Cd+Pb+TOC+Sulfate+TN+TP+MAT,data=combine)
{
  options(na.action = "na.fail") #To set it up globally first
  dd11<-dredge(fit)
  subset(dd11, delta<2) #show the best models
  best11<-model.avg(dd11, subset = delta < 2)
  summary(best11)
  b11<-lm(lys~pH+EC+Fe+TP+MAT,data=combine)
  summary(b11)
  r.squaredGLMM(b11)
  glmm.hp(b11)
  plot(glmm.hp(b11))
  draw = data.frame(glmm.hp(b11)$hierarchical.partitioning)
  draw$value = row.names(draw)
  gvh=ggplot(draw, aes(x = reorder(value, -Individual), y = Individual)) +
    geom_bar(stat = "identity") +
    theme_classic() +
    labs(title = "Log10 CPR VHR",x = "Factor", y = "R2.adj")
  gvh
}


