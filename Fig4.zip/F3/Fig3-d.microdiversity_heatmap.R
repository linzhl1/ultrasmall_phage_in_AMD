library(ggplot2)
library(linkET)
library(ggdendro)

#pi
factordata<-read.table('data\\metadata.tab',header = T,row.names = 1,check.names = FALSE)
factordata = factordata[,c(19:32,35)]
data2 = read.table('data\\p_result.tsv',sep = '\t', stringsAsFactors = FALSE,row.names = 1,header = T)
data2 = as.data.frame(t(data2))
#select clade
factor = factordata
combine = cbind(data2$DPANN,factor)
combine = cbind(data2$CPR,factor)

combine=na.omit(combine)
pi=combine[,1]
env=combine[,2:16]
p1=correlate(pi, env) %>% 
  qcorrplot(cluster_cols = TRUE) +
  geom_tile() +
  geom_mark(only_mark = T)+
  scale_fill_gradientn(colours = rev(c("#5b0018", "#e0745a", "white", "#63a1cb", "#052452")),
                       breaks = seq(-1, 1, 0.2),
                       limits = c(-0.6, 0.6))+
  scale_y_discrete(expand = c(0,0))+ 
  scale_x_discrete(expand = c(0,0))+ 
  theme_bw(base_size = 18)+
  xlab(NULL) + 
  ylab(NULL)+
  theme(panel.border = element_rect(fill=NA,color="white", size=0.5, linetype="solid"),
        )
p1



#theta
factordata<-read.table('data\\metadata.tab',header = T,row.names = 1,check.names = FALSE)
factordata = factordata[,c(19:32,35)]
data2 = read.table('data\\t_result.tsv',sep = '\t', stringsAsFactors = FALSE,row.names = 1,header = T)
data2 = as.data.frame(t(data2))
#select clade
factor = factordata
combine = cbind(data2$DPANN,factor)
combine = cbind(data2$CPR,factor)

combine=na.omit(combine)
theta=combine[,1]
env=combine[,2:16]
p2=correlate(theta, env) %>% 
  qcorrplot(cluster_cols = TRUE) +
  geom_tile() +
  geom_mark(only_mark = T)+
  scale_fill_gradientn(colours = rev(c("#5b0018", "#e0745a", "white", "#63a1cb", "#052452")),
                       breaks = seq(-1, 1, 0.2),
                       limits = c(-0.6, 0.6))+
  scale_y_discrete(expand = c(0,0))+ 
  scale_x_discrete(expand = c(0,0))+ 
  theme_bw(base_size = 18)+
  xlab(NULL) + 
  ylab(NULL)+
  theme(panel.border = element_rect(fill=NA,color="white", size=0.5, linetype="solid"),
  )
p2




  
