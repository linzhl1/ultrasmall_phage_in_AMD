library(vegan)
library(ggplot2)
library(RColorBrewer)

env <- read.delim('data\\MRTgroup.tab', row.names = 1, header = T,sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
datac<-read.table('data\\CPR_relate_vir_abun.tab',header = T,row.names = 1,
                         check.names = FALSE)
datac=t(datac)
datad=read.table('data\\DPANN_relate_vir_abun.tab',header = T,row.names = 1,
                       check.names = FALSE)
datad=t(datad)
dc <- vegdist(datac, method = 'bray')
dp <- vegdist(datad, method = 'bray')

#cpr
{
  nmdsc <- metaMDS(dc, k = 3,try = 200, trymax = 200)
  stressc <- nmdsc$stress
  df <- as.data.frame(nmdsc$points)
  #与分组数据合并
  df <- cbind(df, env$group)
  colnames(df) = c('NMDS1','NMDS2','NMDS3','group')
  df <- df[order(df$group), ]#先按分组排序
  #基于bray-curtis距离进行PERMANOVA分析
  adonis <- adonis2(datac ~ group, data = env, permutations = 999, method = "bray")
  #基于bray-curtis距离进行anosim分析
  anosim = anosim(datac, env$group, permutations = 999, distance = "bray")
  stress_text <- paste("Stress  =", round(stressc, 4))
  adonis_text <- paste(paste("Adonis  =", round(adonis$R2, 2)), "***")[1]
  anosim_text <- paste(paste("Anosim  =", round(anosim$statistic, 2)), "***")
  p <- ggplot(df, aes(NMDS1, NMDS2))+
    geom_point(aes(colour = as.factor(df$group)), size = 3,alpha = 0.7,shape = 16)+
    scale_color_manual(values = c("#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00"))+
    theme_bw()+
    geom_hline(yintercept = 0, linetype = 'dashed', color = "grey60",linewidth=0.8)+
    geom_vline(xintercept = 0, linetype = 'dashed', color = "grey60",linewidth=0.8)+
    theme(legend.position = c(0.9,0.15),
          legend.title = element_blank(),
          panel.grid = element_blank(),
          axis.text = element_text(color = "black",size=10))+
    #theme(legend.position = c(0.5,0.5),legend.text=element_text(size=5))+
    ggtitle(paste(paste(stress_text, adonis_text), anosim_text))
  p
  
  library(ggExtra)
  ggMarginal(p,type="boxplot",
             groupColour = TRUE,
             groupFill = TRUE
  )
}

#dpann
{
  nmdsd <- metaMDS(dp, k = 2,try = 200, trymax = 200)
  stressd <- nmdsd$stress
  df <- as.data.frame(nmdsd$points)
  #与分组数据合并
  df <- cbind(df, env$group)
  colnames(df) = c('NMDS1','NMDS2','group')
  df <- df[order(df$group), ]#先按分组排序
  #基于bray-curtis距离进行PERMANOVA分析
  adonis <- adonis2(datad ~ group, data = env, permutations = 999, method = "bray")
  #基于bray-curtis距离进行anosim分析
  anosim = anosim(datad, env$group, permutations = 999, distance = "bray")
  stress_text <- paste("Stress  =", round(stressd, 4))
  adonis_text <- paste(paste("Adonis  =", round(adonis$R2, 2)), "***")[1]
  anosim_text <- paste(paste("Anosim  =", round(anosim$statistic, 2)), "***")
  p <- ggplot(df, aes(NMDS1, NMDS2))+
    geom_point(aes(colour = as.factor(df$group)), size = 3,alpha = 0.7,shape = 16)+
    scale_color_manual(values = c("#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00"))+
    theme_bw()+
    geom_hline(yintercept = 0, linetype = 'dashed', color = "grey60",linewidth=0.8)+
    geom_vline(xintercept = 0, linetype = 'dashed', color = "grey60",linewidth=0.8)+
    theme(legend.position = c(0.9,0.15),
          legend.title = element_blank(),
          panel.grid = element_blank(),
          axis.text = element_text(color = "black",size=10))+
    #theme(legend.position = c(0.5,0.5),legend.text=element_text(size=5))+
    ggtitle(paste(paste(stress_text, adonis_text), anosim_text))
  p
  
  library(ggExtra)
  ggMarginal(p,type="boxplot",
             groupColour = TRUE,
             groupFill = TRUE
  )
}
