library(vegan)
library(dplyr)

#CPR
votu<-read.table('data\\CPR_relate_vir_abun.tab',header = T)
votu<-decostand(t(votu),method='hellinger')
distv<-vegdist(votu,method = 'bray')
distv_num<-1-as.numeric(distv)
distv_num=log10(distv_num+0.001)
library(SoDA)
loca<-read.table('data\\site.lat_lng',header = T)
xy_loca<-geoXY(loca$lat,loca$lng)
rownames(xy_loca)<-rownames(loca)
dist_loca<-vegdist(xy_loca,method = 'euclidean')
dist_loca_log<-log10(dist_loca)
dist_loca_num<-as.numeric(dist_loca_log)
data_new<-data.frame(distv_num,dist_loca_num)
data_new$group<-ifelse(data_new$dist_loca_num < 3, "Local","Regional")
data_new$group<-as.factor(data_new$group)
data_local<-data_new[which(data_new$group == "Local"),]
data_regional<-data_new[which(data_new$group == "Regional"),]
lmall<-lm(distv_num~dist_loca_num,data=data_new)
lmall
summary(lmall)
lmlocal<-lm(distv_num~dist_loca_num,data=data_local)
lmlocal
summary(lmlocal)
lmregional<-lm(distv_num~dist_loca_num,data=data_regional)
lmregional
summary(lmregional)





###DPANN
pc<-read.table('data\\DPANN_relate_vir_abun.tab',header = T)
pc<-decostand(t(pc),method='hellinger')
distp<-vegdist(pc,method = 'bray')
distpc_num<-1-as.numeric(distp)
distpc_num=log10(distpc_num + 0.001)
data_new<-data.frame(distpc_num,dist_loca_num)
data_new$group<-ifelse(data_new$dist_loca_num < 3, "Local","Regional")
data_new$group<-as.factor(data_new$group)
data_local<-data_new[which(data_new$group == "Local"),]
data_regional<-data_new[which(data_new$group == "Regional"),]
lmall<-lm(distpc_num~dist_loca_num,data=data_new)
lmall
summary(lmall)
lmlocal<-lm(distpc_num~dist_loca_num,data=data_local)
lmlocal
summary(lmlocal)
lmregional<-lm(distpc_num~dist_loca_num,data=data_regional)
lmregional
summary(lmregional)
