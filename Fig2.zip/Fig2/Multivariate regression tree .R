library(mvpart)
library(MVPARTwrap)
library(vegan)
library(patchwork)
library(reshape2)
library(ggplot2)
library(ggpubr)


env <- read.delim('data\\metadata.tab', row.names = 1, header = T,sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
species2 <- read.table('data\\clade_vir_abun.tab',header = T,row.names = 1,
                       check.names = FALSE)
species2 = t(species2)
species<-decostand(species2,method = "total")
env = env[,19:36]

set.seed(20240522)
par(mfrow=c(3,1))
spider_mvpart <- mvpart(mvpart::gdist(species, meth="bray", full=TRUE, sq=TRUE)~., env, xval = nrow(species)*10, xvmult = 1000, xv = 'pick', pca = F)
summary(spider_mvpart)
printcp(spider_mvpart)
spider_mvpart$cptable
nfactor = read.delim('data\\metadata.tab', row.names = 1, header = T,sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
nfactor$group = as.factor(spider_mvpart$where)
nfactor$crate = nfactor$CPR_abun/nfactor$mabun
nfactor$drate = nfactor$DPANN_abun/nfactor$mabun
pc=ggplot(nfactor, aes(x=group, y=crate)) + 
  geom_boxplot()+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),axis.line.x = element_line(size = 0.5),
        axis.line.y = element_line(size=0.5),axis.text.x = element_text(size=14,color = "black"),
        axis.text.y = element_text(size=14,color="black"),axis.title.x = element_text(size=14),
        axis.title.y = element_text(size=14))+
  xlab(NULL)+
  theme(axis.text.x = element_blank())
pd=ggplot(nfactor, aes(x=group, y=drate)) +
  geom_boxplot()+
  theme_bw()+
  theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),axis.line.x = element_line(size = 0.5),
        axis.line.y = element_line(size=0.5),axis.text.x = element_text(size=14,color = "black"),
        axis.text.y = element_text(size=14,color="black"),axis.title.x = element_text(size=14),
        axis.title.y = element_text(size=14))+
  xlab(NULL)+
  theme(axis.text.x = element_blank())


# Sulfate
{
  sdata = nfactor
  sdata$ngroup=dplyr::recode(sdata$group, "4" = "1", "5" = "2","7" = "3", "8" = "4","10" = "6", "11" = "7")
  sdata$ngroup = as.numeric(sdata$ngroup)
  ggpubr::compare_means(Sulfate ~ ngroup, data = sdata,
                method = "kruskal.test")
  Sulfate = ggplot(sdata, aes(x=ngroup, y=Sulfate)) +
    ##'@添加误差线
    stat_summary(fun.data = "mean_se", geom = "errorbar",
                 width = 0.2, size = 0.8)+
    ##'@绘制柱状图
    geom_bar(stat = "summary", position = "dodge",width =0.75,
             color = c("black"),
             fun = mean, size = 0.5)+
    theme_bw()+
    theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),axis.line.x = element_line(size = 0.5),
          axis.line.y = element_line(size=0.5),axis.text.x = element_text(size=10,color = "black"),
          axis.text.y = element_text(size=10,color="black"),axis.title.x = element_text(size=14),
          axis.title.y = element_text(size=14))+
    xlab(NULL)+
    ylab(NULL)+
    #facet_grid(. ~ title)+
    scale_x_continuous(limits=c(0.5,7.5),breaks=c(1,2,3,4,5,6,7),
                       labels = c('A','B','C','D','','E','F'))+#改变X轴
    theme(axis.ticks.x = element_blank())#关闭X轴刻度
  Sulfate
}
# Pb
{
  pbdata = rbind(subset(nfactor,nfactor$group=='10'),subset(nfactor,nfactor$group=='11'))
  ggpubr::compare_means(Pb ~ group, data = pbdata,
                        method = "kruskal.test")
  Pb = ggplot(pbdata, aes(x=group, y=Pb)) +
    ##'@添加误差线
    stat_summary(fun.data = "mean_se", geom = "errorbar",
                 width = 0.2, size = 0.8)+
    ##'@绘制柱状图
    geom_bar(stat = "summary", position = "stack",width =0.75,
             color = c("black"),
             fun = mean, size = 0.5)+
    theme_bw()+
    theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),axis.line.x = element_line(size = 0.5),
          axis.line.y = element_line(size=0.5),axis.text.x = element_text(size=10,color = "black"),
          axis.text.y = element_text(size=10,color="black"),axis.title.x = element_text(size=14),
          axis.title.y = element_text(size=14))+
    xlab(NULL)+
    #facet_grid(. ~ title)+
    ylab(NULL)
  Pb
}
# Fe
{
  fedata = rbind(subset(nfactor,nfactor$group=='4'),subset(nfactor,nfactor$group=='5'),subset(nfactor,nfactor$group=='7'),subset(nfactor,nfactor$group=='8'))
  fedata$ngroup=dplyr::recode(fedata$group, "4" = "1", "5" = "2","7" = "4", "8" = "5")
  fedata$ngroup = as.numeric(fedata$ngroup)
  ggpubr::compare_means(Fe ~ group, data = fedata,
                        method = "kruskal.test")
  Fe = ggplot(fedata, aes(x=ngroup, y=Fe)) +
    ##'@添加误差线
    stat_summary(fun.data = "mean_se", geom = "errorbar",
                 width = 0.2, size = 0.8)+
    ##'@绘制柱状图
    geom_bar(stat = "summary", position = "stack",width =0.75,
             color = c("black"),
             fun = mean, size = 0.5)+
    theme_bw()+
    theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),axis.line.x = element_line(size = 0.5),
          axis.line.y = element_line(size=0.5),axis.text.x = element_text(size=10,color = "black"),
          axis.text.y = element_text(size=10,color="black"),axis.title.x = element_text(size=14),
          axis.title.y = element_text(size=14))+
    xlab(NULL)+
    ylab(NULL)+
    #facet_grid(. ~ title)+
    scale_x_continuous(limits=c(0.5,5.5),breaks=c(1,2,3,4,5),
                       labels = c('A','B','','C','D'))+#改变X轴
    theme(axis.ticks.x = element_blank())#关闭X轴刻度
  Fe
}
# EC
{
  ECdata = rbind(subset(nfactor,nfactor$group=='4'),subset(nfactor,nfactor$group=='5'))
  ggpubr::compare_means(EC ~ group, data = ECdata,
                        method = "kruskal.test")
  EC = ggplot(ECdata, aes(x=group, y=EC)) +
    ##'@添加误差线
    stat_summary(fun.data = "mean_se", geom = "errorbar",
                 width = 0.2, size = 0.8)+
    ##'@绘制柱状图
    geom_bar(stat = "summary", position = "stack",width =0.75,
             color = c("black"),
             fun = mean, size = 0.5)+
    theme_bw()+
    theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),axis.line.x = element_line(size = 0.5),
          axis.line.y = element_line(size=0.5),axis.text.x = element_text(size=10,color = "black"),
          axis.text.y = element_text(size=10,color="black"),axis.title.x = element_text(size=14),
          axis.title.y = element_text(size=14))+
    xlab(NULL)+
    #facet_grid(. ~ title)+
    ylab(NULL)
  EC
}
# pH
{
  pHdata = rbind(subset(nfactor,nfactor$group=='7'),subset(nfactor,nfactor$group=='8'))
  ggpubr::compare_means(pH ~ group, data = pHdata,
                        method = "kruskal.test")
  pH = ggplot(pHdata, aes(x=group, y=pH)) +
    ##'@添加误差线
    stat_summary(fun.data = "mean_se", geom = "errorbar",
                 width = 0.2, size = 0.8)+
    ##'@绘制柱状图
    geom_bar(stat = "summary", position = "stack",width =0.75,
             color = c("black"),
             fun = mean, size = 0.5)+
    theme_bw()+
    theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),axis.line.x = element_line(size = 0.5),
          axis.line.y = element_line(size=0.5),axis.text.x = element_text(size=10,color = "black"),
          axis.text.y = element_text(size=10,color="black"),axis.title.x = element_text(size=14),
          axis.title.y = element_text(size=14))+
    xlab(NULL)+
    #facet_grid(. ~ title)+
    ylab(NULL)
  pH
}
design1 <- "
  111111
  222233
  445533
"
Sulfate+Fe+Pb+EC+pH+plot_layout(design = design1)


#PC1
otu_pca=prcomp(species, scal=FALSE)
pc12=otu_pca$x[, 1:2]/100
pc12=as.data.frame(pc12)
pca_sum=summary(otu_pca)
pcap=as.vector(round(pca_sum$importance[2, 1:2], 3), mode="any")
pcapp=paste(pcap*100, "%",sep="")
pcap1=paste("PC1(", pcapp[1], ")", sep="")

library(psych)
res <- corr.test(pc12$PC1,factor,use="pairwise",
                 method = "pearson",
                 alpha=0.05)
res$r
res$p