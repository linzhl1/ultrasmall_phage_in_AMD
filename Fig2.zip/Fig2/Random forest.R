library(ggplot2)
library(linkET)
library(rfPermute)
library(vegan)
library(patchwork)
library(tidyr)


factordata<-read.table('data\\metadata.tab',header = T,row.names = 1,check.names = FALSE)
factordata = factordata[,c(19:32,35:36)]
library('Hmisc')
co_linear <- varclus(as.matrix(factordata), similarity="spear")
co_linear
plot(co_linear)
factordata <- select(factordata,-c(MAP,Zn))
library(dplyr)
sysdata <-factordata[,1:2]
dvabun = read.table('data\\DPANN_relate_vir_abun.tab',sep = '\t', stringsAsFactors = FALSE,row.names = 1,header = T,check.names = F)
cvabun = read.table('data\\CPR_relate_vir_abun.tab',sep = '\t', stringsAsFactors = FALSE,row.names = 1,header = T,check.names = F)
dabun = read.table('data\\DPANN_all_abun.tab',sep = '\t', stringsAsFactors = FALSE,row.names = 1,header = T,check.names = F)
cabun = read.table('data\\CPR_all_abun.tab',sep = '\t', stringsAsFactors = FALSE,row.names = 1,header = T,check.names = F)
sysdata$DPANN_host = colSums(dabun)
sysdata$CPR_host = colSums(cabun)
sysdata$DPANN_vir = colSums(dvabun)
sysdata$CPR_vir = colSums(cvabun)
sysdata = sysdata[,3:6]

# alpha
cvabun=t(cvabun)
dvabun=t(dvabun)
cShannon <- diversity(t(cvabun), index = "shannon", MARGIN = 2, base = exp(1))
cSimpson <- diversity(t(cvabun), index = "simpson", MARGIN = 2, base =  exp(1))
cRichness <- specnumber(t(cvabun), MARGIN = 2)
dShannon <- diversity(t(dvabun), index = "shannon", MARGIN = 2, base = exp(1))
dSimpson <- diversity(t(dvabun), index = "simpson", MARGIN = 2, base =  exp(1))
dRichness <- specnumber(t(dvabun), MARGIN = 2)
index <- as.data.frame(cbind(cShannon, cSimpson, cRichness, dShannon, dSimpson, dRichness))
ctdf<-ceiling(as.data.frame(cvabun))
dtdf<-ceiling(as.data.frame(dvabun))
cobs_chao_ace <- t(estimateR(ctdf))
cobs_chao_ace <- cobs_chao_ace[rownames(index),]
dobs_chao_ace <- t(estimateR(dtdf))
dobs_chao_ace <- dobs_chao_ace[rownames(index),]
index$cChao <- cobs_chao_ace[,2]
index$cAce <- cobs_chao_ace[,4]
index$cobs <- cobs_chao_ace[,1]
index$dChao <- dobs_chao_ace[,2]
index$dAce <- dobs_chao_ace[,4]
index$dobs <- dobs_chao_ace[,1]
# Pielou
index$cPielou <- cShannon / log(cRichness, 2)
index$dPielou <- dShannon / log(dRichness, 2)
# result
sysdata$cvOTU = index$cRichness
sysdata$cChao = index$cChao
sysdata$cShannon = index$cShannon
sysdata$cPielou = index$cPielou
sysdata$dvOTU = index$dRichness
sysdata$dChao = index$dChao
sysdata$dShannon = index$dShannon
sysdata$dPielou = index$dPielou
row.names(sysdata) = row.names(factordata)


args(random_forest)
rf <- random_forest(sysdata, factordata)

px <- correlate(sysdata, factordata) %>% 
  qcorrplot(extra_mat = list(importance = rf$importance,
                             pvalue = rf$p),
            fixed = FALSE) +
  coord_flip() +
  geom_tile() +
  geom_point(aes(size = importance), shape = 1,
             stroke = 0.6,
             color = 'black',
             data = function(data) data[data$pvalue < 0.05, , drop = FALSE]) +
  scale_fill_gradientn(colours = rev(c("#5b0018", "#e0745a", "white", "#63a1cb", "#052452")), 
                       breaks = seq(-1, 1, 0.2),
                       limits = c(-0.5, 0.5))+ 
  scale_size_continuous(name = 'Importance(%)',
                        limit = c(-0.001,15.1),
                        breaks = c(0,5,10,15))+
  scale_y_discrete(expand = c(0,0))+ 
  scale_x_discrete(expand = c(0,0))+ 
  theme_bw()+
  xlab(NULL) + 
  ylab(NULL)+
  theme(panel.border = element_rect(fill=NA,color="black", size=0.5, linetype="solid"))


p2 <- ggplot(rf$explained, aes(name, explained)) +
  geom_bar(stat = 'identity',
           fill = 'steelblue')+
  xlab(NULL) + 
  ylab('Exp var(%)')+
  theme_bw()+
  theme(panel.grid.major=element_blank(),
        panel.grid.minor=element_blank(),
        axis.text.x = element_blank())

p2/px+plot_layout(ncol = 1,
                  heights = c(0.5, 2))