library(ggplot2)
#library(linkET)
#library(rfPermute)
library(vegan)
library(patchwork)
library(tidyr)
library(dplyr)
library("leaps")
library(glmm.hp)
library(car)
library(lmtest)
library(gvlma)
library('Hmisc')
library(robustbase)
library(gridExtra)



#setwd("C:\\ondrive备份\\AMD博士课题\\超微型微生物\\分析\\virus\\all_vh\\without_ref\\Manuscript\\final\\revision\\fig3-life\\F3")

factordata<-read.table('data\\metadata.tab',header = T,row.names = 1,check.names = FALSE)
{
  dvabun = read.table('data\\DPANN_relate_vir_abun.tab',sep = '\t', stringsAsFactors = FALSE,row.names = 1,header = T,check.names = F)
  cvabun = read.table('data\\CPR_relate_vir_abun.tab',sep = '\t', stringsAsFactors = FALSE,row.names = 1,header = T,check.names = F)
  dabun = read.table('data\\DPANN_abun.tab',sep = '\t', stringsAsFactors = FALSE,row.names = 1,header = T,check.names = F)
  cabun = read.table('data\\CPR_abun.tab',sep = '\t', stringsAsFactors = FALSE,row.names = 1,header = T,check.names = F)
  # The lifestyle prediction results corrected by Pfam and CheckV
  lifetab = read.table('data\\final_life.csv',sep = ',', stringsAsFactors = FALSE,header = T,check.names = F)
  lifetab <- lifetab %>%
    mutate(final3 = case_when(
      pfam == "temperate" | checkv == "yes" ~ "temperate",
      TRUE ~ deephage  
    ))
  dvabun_virulent = dvabun[rownames(dvabun) %in% lifetab[lifetab$final3 == 'virulent',]$name,]
  dvabun_temp = dvabun[rownames(dvabun) %in% lifetab[lifetab$final3 == 'temperate',]$name,]
  cvabun_virulent = cvabun[rownames(cvabun) %in% lifetab[lifetab$final3 == 'virulent',]$name,]
  cvabun_temp = cvabun[rownames(cvabun) %in% lifetab[lifetab$final3 == 'temperate',]$name,]
  dvabun_virulent = colSums(dvabun_virulent)
  dvabun_temp = colSums(dvabun_temp)
  cvabun_virulent = colSums(cvabun_virulent)
  cvabun_temp = colSums(cvabun_temp)
  life_abun = data.frame(dvabun_virulent,dvabun_temp,cvabun_virulent,cvabun_temp)
  life_abun$cLysogenic_rate = life_abun$cvabun_temp/(cvabun_virulent+cvabun_temp)
  life_abun$dLysogenic_rate = life_abun$dvabun_temp/(dvabun_virulent+dvabun_temp)
  life_abun$cvabun = cvabun_virulent + cvabun_temp
  life_abun$dvabun = dvabun_virulent + dvabun_temp
  life_abun$cvh = life_abun$cvabun/colSums(cabun)
  life_abun$dvh = life_abun$dvabun/colSums(dabun)
  life_abun$cabun = colSums(cabun)
  life_abun$dabun = colSums(dabun)
  sysdata = life_abun
}
factordata = factordata[,c(19:32,35:36)]
co_linear <- varclus(as.matrix(factordata), similarity="spear")
co_linear
plot(co_linear)
factordata <- dplyr::select(factordata,-c(MAP,Zn))
factordata = factordata[!is.infinite(rowSums(sysdata)),]
sysdata <- sysdata[!is.infinite(rowSums(sysdata)),]
sysdata$logcvh = log10(sysdata$cvh)
sysdata$logdvh = log10(sysdata$dvh)
factordata = factordata[!factordata$EC > 7, ]
factordata = factordata[!factordata$pH < 2, ]
factordata = decostand(factordata,method = "standardize")
sysdata <- sysdata[rownames(sysdata) %in% rownames(factordata), ]
combine<-cbind(sysdata,factordata)


univariate_robust_regression <- function(response, data = combine, predictors = NULL) {
  
  predictors <- c("pH", "EC", "Fe", "Ferric", "Ferrous", "Cu", "Mn", 
                  "Cd", "Pb", "TOC", "Sulfate", "TN", "TP", "MAT")

  # 初始化结果数据框
  results <- data.frame(
    Variable = character(),
    R_squared = numeric(),
    P_value = numeric(),
    stringsAsFactors = FALSE
  )
  
  # 循环处理每个预测变量
  for (i in seq_along(predictors)) {
    var <- predictors[i]
    formula <- as.formula(paste(response, "~", var))
    
    # 拟合稳健回归模型
    set.seed(20250611)
    options(na.action = "na.fail")
    model <- lmrob(formula, data = data, setting = "KS2014")
    
    # 提取模型结果
    model_summary <- summary(model)
    
    # 获取系数和p值
    coef_df <- as.data.frame(model_summary$coefficients)
    p_value <- coef_df[2, 4]  # 自变量的p值
    
    # 计算R²
    r_squared <- model_summary$r.squared
    
    # 保存结果
    results <- rbind(results, data.frame(
      Variable = var,
      R_squared = r_squared,
      P_value = p_value
    ))
  }
  
  # 过滤数据，只保留P_value < 0.1的结果并添加显著性标记
  filtered_results <- results %>%
    mutate(
      Significance = case_when(
        P_value < 0.001 ~ "***",
        P_value < 0.01 ~ "**",
        P_value < 0.05 ~ "*",
        P_value < 0.1 ~ ".",
        TRUE ~ "ns"
      ),
      Label = Significance
    )
  
  r2_plot <- ggplot(filtered_results, aes(x = reorder(Variable, -R_squared), y = R_squared)) +
    geom_bar(stat = "identity", alpha = 0.8) +
    geom_text(aes(label = Label), vjust = -0.5, size = 3, color = "black") +
    labs(
      x = "Predictor Variables",
      y = "R-squared"
    ) +
    theme_classic() +
    ylim(0, max(filtered_results$R_squared) * 1.2) +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
  
  return(r2_plot)
}




#logcvh
{
  fit<-lm(logcvh~pH+EC+Fe+Ferric+Ferrous+Cu+Mn+Cd+Pb+TOC+Sulfate+TN+TP+MAT,data=combine)
  gvmodel <- gvlma(fit)
  summary(gvmodel)
  plot(fit, which = 2)
  residuals <- resid(fit)
  shapiro.test(residuals)

  
  set.seed(20250611)
  options(na.action = "na.fail")
  global_model_rlm <- lmrob(
    logcvh ~ pH + EC + Fe + Ferric + Ferrous + Cu + Mn + Cd + Pb + TOC + Sulfate + TN + TP + MAT,
    data = combine,
    setting = "KS2014"
  )
  summary(global_model_rlm)
  #评估
  # 绘制四合一诊断图
  plot(global_model_rlm) 
  # 提取观测权重
  weights <- global_model_rlm$rweights
  low_weight_obs <- which(weights < 0.5)  # 权重<0.5的异常值
  # 报告异常值比例
  cat("Proportion of outliers:", length(low_weight_obs)/nrow(combine)*100, "%")
  
  results <- data.frame()
  residual_plots <- list()
  cvhr_plot <- univariate_robust_regression("logcvh")
  print(cvhr_plot)
}


#cLysogenic_rate
{
  fit<-lm(cLysogenic_rate~pH+EC+Fe+Ferric+Ferrous+Cu+Mn+Cd+Pb+TOC+Sulfate+TN+TP+MAT,data=combine)
  gvmodel <- gvlma(fit)
  summary(gvmodel)
  plot(fit, which = 2)
  residuals <- resid(fit)
  shapiro.test(residuals)

  
  set.seed(20250611)
  options(na.action = "na.fail")
  global_model_rlm <- lmrob(
    cLysogenic_rate ~ pH + EC + Fe + Ferric + Ferrous + Cu + Mn + Cd + Pb + TOC + Sulfate + TN + TP + MAT,
    data = combine,
    setting = "KS2014"
  )
  summary(global_model_rlm)
  #评估
  # 绘制四合一诊断图
  plot(global_model_rlm) 
  # 提取观测权重
  weights <- global_model_rlm$rweights
  low_weight_obs <- which(weights < 0.5)  # 权重<0.5的异常值
  # 报告异常值比例
  cat("Proportion of outliers:", length(low_weight_obs)/nrow(combine)*100, "%")
  
  results <- data.frame()
  residual_plots <- list()
  cly_plot <- univariate_robust_regression("cLysogenic_rate")
  print(cly_plot)
}


#logdvh
{
  fit<-lm(logdvh~pH+EC+Fe+Ferric+Ferrous+Cu+Mn+Cd+Pb+TOC+Sulfate+TN+TP+MAT,data=combine)
  gvmodel <- gvlma(fit)
  summary(gvmodel)
  plot(fit, which = 2)
  residuals <- resid(fit)
  shapiro.test(residuals)

  
  set.seed(20250611)
  options(na.action = "na.fail")
  global_model_rlm <- lmrob(
    logdvh ~ pH + EC + Fe + Ferric + Ferrous + Cu + Mn + Cd + Pb + TOC + Sulfate + TN + TP + MAT,
    data = combine,
    setting = "KS2014"
  )
  summary(global_model_rlm)
  #评估
  # 绘制四合一诊断图
  plot(global_model_rlm) 
  # 提取观测权重
  weights <- global_model_rlm$rweights
  low_weight_obs <- which(weights < 0.5)  # 权重<0.5的异常值
  # 报告异常值比例
  cat("Proportion of outliers:", length(low_weight_obs)/nrow(combine)*100, "%")
  
  results <- data.frame()
  residual_plots <- list()
  dvhr_plot <- univariate_robust_regression("logdvh")
  print(dvhr_plot)
}


#dLysogenic_rate
{
  fit<-lm(dLysogenic_rate~pH+EC+Fe+Ferric+Ferrous+Cu+Mn+Cd+Pb+TOC+Sulfate+TN+TP+MAT,data=combine)
  gvmodel <- gvlma(fit)
  summary(gvmodel)
  plot(fit, which = 2)
  residuals <- resid(fit)
  shapiro.test(residuals)

  
  set.seed(20250611)
  options(na.action = "na.fail")
  global_model_rlm <- lmrob(
    dLysogenic_rate ~ pH + EC + Fe + Ferric + Ferrous + Cu + Mn + Cd + Pb + TOC + Sulfate + TN + TP + MAT,
    data = combine,
    setting = "KS2014"
  )
  summary(global_model_rlm)
  #评估
  # 绘制四合一诊断图
  plot(global_model_rlm) 
  # 提取观测权重
  weights <- global_model_rlm$rweights
  low_weight_obs <- which(weights < 0.5)  # 权重<0.5的异常值
  # 报告异常值比例
  cat("Proportion of outliers:", length(low_weight_obs)/nrow(combine)*100, "%")
  
  results <- data.frame()
  residual_plots <- list()
  dly_plot <- univariate_robust_regression("dLysogenic_rate")
  print(dly_plot)
}
(cvhr_plot+cly_plot)/(dvhr_plot+dly_plot)





# ABT
library(gbm)
# logcvh
fit_1 <- gbm(logcvh~pH+EC+Fe+Ferric+Ferrous+Cu+Mn+Cd+Pb+TOC+Sulfate+TN+TP+MAT, 
             data = combine, 
             n.trees = 5000, 
             cv.folds = 10
)
print(fit_1) 
summary(fit_1)
perf_gbm1 = gbm.perf(fit_1, method = "cv")
perf_gbm1
# Extract variable importance and select the top 10 variables.
var_importance <- summary(fit_1, plotit = FALSE) %>%
  arrange(desc(rel.inf)) %>%
  head(10)
# 绘制条形图
gcvh=ggplot(var_importance, aes(x = reorder(var, rel.inf), y = rel.inf)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  coord_flip() +  # 横向条形图便于阅读变量名
  labs(
    title = "Top 10 Important Variables in GBM Model",
    x = "Variables",
    y = "Relative Influence"
  ) +
  theme_classic() +
  theme(plot.title = element_text(hjust = 0.5))  # 标题居中


# cLysogenic_rate
fit_1 <- gbm(cLysogenic_rate~EC+Fe+Ferric+Ferrous+Cu+Mn+Cd+Pb+TOC+Sulfate+TN+TP+MAT, 
             data = combine, 
             n.trees = 5000, 
             cv.folds = 10
)
print(fit_1) 
summary(fit_1)
perf_gbm1 = gbm.perf(fit_1, method = "cv")
perf_gbm1
var_importance <- summary(fit_1, plotit = FALSE) %>%
  arrange(desc(rel.inf)) %>%
  head(10)
# 绘制条形图
gcly=ggplot(var_importance, aes(x = reorder(var, rel.inf), y = rel.inf)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  coord_flip() +  # 横向条形图便于阅读变量名
  labs(
    title = "Top 10 Important Variables in GBM Model",
    x = "Variables",
    y = "Relative Influence"
  ) +
  theme_classic() +
  theme(plot.title = element_text(hjust = 0.5))  # 标题居中


# dLysogenic_rate
set.seed(20250611)
fit_1 <- gbm(dLysogenic_rate~pH+EC+Fe+Ferric+Ferrous+Cu+Mn+Cd+Pb+TOC+Sulfate+TN+TP+MAT, 
             data = combine, 
             n.trees = 5000, 
             cv.folds = 10
)
print(fit_1) 
summary(fit_1)
perf_gbm1 = gbm.perf(fit_1, method = "cv")
perf_gbm1
var_importance <- summary(fit_1, plotit = FALSE) %>%
  arrange(desc(rel.inf)) %>%
  head(10)
# 绘制条形图
gdly=ggplot(var_importance, aes(x = reorder(var, rel.inf), y = rel.inf)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  coord_flip() +  # 横向条形图便于阅读变量名
  labs(
    title = "Top 10 Important Variables in GBM Model",
    x = "Variables",
    y = "Relative Influence"
  ) +
  theme_classic() +
  theme(plot.title = element_text(hjust = 0.5))  # 标题居中


# logdvh
set.seed(20250611)
fit_1 <- gbm(logdvh~pH+EC+Fe+Ferric+Ferrous+Cu+Mn+Cd+Pb+TOC+Sulfate+TN+TP+MAT, 
             data = combine, 
             n.trees = 5000, 
             cv.folds = 10
)
print(fit_1) 
summary(fit_1)
perf_gbm1 = gbm.perf(fit_1, method = "cv")
perf_gbm1
var_importance <- summary(fit_1, plotit = FALSE) %>%
  arrange(desc(rel.inf)) %>%
  head(10)
# 绘制条形图
gdvh=ggplot(var_importance, aes(x = reorder(var, rel.inf), y = rel.inf)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  coord_flip() +  # 横向条形图便于阅读变量名
  labs(
    title = "Top 10 Important Variables in GBM Model",
    x = "Variables",
    y = "Relative Influence"
  ) +
  theme_classic() +
  theme(plot.title = element_text(hjust = 0.5))  # 标题居中


(gcvh+gcly)/(gdvh+gdly)
perf_gbm1 = gbm.perf(fit_1, method = "cv")
perf_gbm1
