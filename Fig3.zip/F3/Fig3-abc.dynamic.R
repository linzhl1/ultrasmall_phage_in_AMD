library(ggplot2)
library(ggpubr)
library(patchwork)
library(dplyr)

factordata<-read.table('data\\metadata.tab',header = T,row.names = 1,check.names = FALSE)
{
  dvabun = read.table('data\\DPANN_relate_vir_abun.tab',sep = '\t', stringsAsFactors = FALSE,row.names = 1,header = T,check.names = F)
  cvabun = read.table('data\\CPR_relate_vir_abun.tab',sep = '\t', stringsAsFactors = FALSE,row.names = 1,header = T,check.names = F)
  dabun = read.table('data\\DPANN_abun.tab',sep = '\t', stringsAsFactors = FALSE,row.names = 1,header = T,check.names = F)
  cabun = read.table('data\\CPR_abun.tab',sep = '\t', stringsAsFactors = FALSE,row.names = 1,header = T,check.names = F)
  #  The lifestyle prediction results corrected by Pfam and CheckV
  lifetab = read.table('data\\final_life.csv',sep = ',', stringsAsFactors = FALSE,header = T,check.names = F)
  lifetab <- lifetab %>%
    mutate(final3 = case_when(
      pfam == "temperate" | checkv == "yes" ~ "temperate",
      TRUE ~ deephage  # 其他情况保留原值
    ))
  dvabun_virulent = dvabun[rownames(dvabun) %in% lifetab[lifetab$final3 == 'virulent',]$name,]
  dvabun_temp = dvabun[rownames(dvabun) %in% lifetab[lifetab$final3 == 'temperate',]$name,]
  cvabun_virulent = cvabun[rownames(cvabun) %in% lifetab[lifetab$final3 == 'virulent',]$name,]
  cvabun_temp = cvabun[rownames(cvabun) %in% lifetab[lifetab$final3 == 'temperate',]$name,]
  dvabun_virulent = colSums(dvabun_virulent)
  dvabun_temp = colSums(dvabun_temp)
  cvabun_virulent = colSums(cvabun_virulent)
  cvabun_temp = colSums(cvabun_temp)
  life_abun = data.frame(dvabun_virulent,dvabun_temp,cvabun_virulent,cvabun_temp)
  life_abun$cLysogenic_rate = life_abun$cvabun_temp/(cvabun_virulent+cvabun_temp)
  life_abun$dLysogenic_rate = life_abun$dvabun_temp/(dvabun_virulent+dvabun_temp)
  life_abun$cvabun = cvabun_virulent + cvabun_temp
  life_abun$dvabun = dvabun_virulent + dvabun_temp
  life_abun$cvh = life_abun$cvabun/colSums(cabun)
  life_abun$dvh = life_abun$dvabun/colSums(dabun)
  life_abun$cabun = colSums(cabun)
  life_abun$dabun = colSums(dabun)
  sysdata = life_abun
  factordata = factordata[!is.infinite(rowSums(sysdata)),]
  sysdata <- sysdata[!is.infinite(rowSums(sysdata)),]
  sysdata$logcvh = log(sysdata$cvh)
  sysdata$logdvh = log(sysdata$dvh)
  combine = cbind(factordata,sysdata)
  combine = combine[!combine$EC > 7, ]
  combine = combine[!combine$pH < 2, ]
}
#EC-VH
{
  ctemp2 = data.frame(EC = combine$EC, log10_vh = combine$logcvh, group = 'CPR')
  dtemp2 = data.frame(EC = combine$EC, log10_vh = combine$logdvh, group = 'DPANN')
  temp2 = rbind(ctemp2,dtemp2)
  ecvh=ggplot(temp2, aes(x = EC, y = log10_vh)) +
    geom_point(size=2,color="gray")+
    facet_wrap("~ group",scales = "free_x") + # 列分面
    geom_smooth(method="lm",fill= NA,level=0, color = "#4682B4")+
    stat_cor(label.sep = '\n')+
    labs(x="EC",y="Log10 VHRs")+
    theme_bw(base_size = 18)+
    theme(panel.border = element_blank(),
          panel.grid = element_blank(),
          axis.line = element_line(),,axis.text.y = element_text(angle = 90, hjust = 0.5, vjust = 0.5))
  ecvh
}

#abun-VH
{
  ctemp2 = data.frame(EC = combine$cabun, log10_vh = combine$logcvh, group = 'CPR')
  dtemp2 = data.frame(EC = combine$dabun, log10_vh = combine$logdvh, group = 'DPANN')
  temp2 = rbind(ctemp2,dtemp2)
  abunvh=ggplot(temp2, aes(x = EC, y = log10_vh)) +
    geom_point(size=2,color="gray")+
    facet_wrap("~ group",scales = "free_x") + # 列分面
    geom_smooth(method="lm",fill= NA,level=0, color = "#4682B4")+
    stat_cor(label.sep = '\n')+
    labs(x="Abundance",y="Log10 VHRs")+
    theme_bw(base_size = 18)+
    theme(panel.border = element_blank(),
          panel.grid = element_blank(),
          axis.line = element_line(),,axis.text.y = element_text(angle = 90, hjust = 0.5, vjust = 0.5))
  abunvh
}

#abun-lys
{
  ctemp2 = data.frame(EC = combine$cabun, log10_vh = combine$cLysogenic_rate*100, group = 'CPR')
  dtemp2 = data.frame(EC = combine$dabun, log10_vh = combine$dLysogenic_rate*100, group = 'DPANN')
  temp2 = rbind(ctemp2,dtemp2)
  abunlys=ggplot(temp2, aes(x = EC, y = log10_vh)) +
    geom_point(size=2,color="gray")+
    facet_wrap("~ group",scales = "free_x") + # 列分面
    geom_smooth(method="lm",fill= NA,level=0, color = "#4682B4")+
    stat_cor(label.sep = '\n')+
    labs(x="Abundance",y="Lysogenic rate (%)")+
    theme_bw(base_size = 18)+
    theme(panel.border = element_blank(),
          panel.grid = element_blank(),
          axis.line = element_line(),axis.text.y = element_text(angle = 90, hjust = 0.5, vjust = 0.5))
  abunlys
}

#EC-lys
{
  ctemp2 = data.frame(EC = combine$EC, log10_vh = combine$cLysogenic_rate*100, group = 'CPR')
  dtemp2 = data.frame(EC = combine$EC, log10_vh = combine$dLysogenic_rate*100, group = 'DPANN')
  temp2 = rbind(ctemp2,dtemp2)
  eclys=ggplot(temp2, aes(x = EC, y = log10_vh)) +
    geom_point(size=2,color="gray")+
    facet_wrap("~ group",scales = "free_x") + # 列分面
    geom_smooth(method="lm",fill= NA,level=0, color = "#4682B4")+
    stat_cor(label.sep = '\n')+
    labs(x="EC",y="Lysogenic rate (%)")+
    theme_bw(base_size = 18)+
    theme(panel.border = element_blank(),
          panel.grid = element_blank(),
          axis.line = element_line(),axis.text.y = element_text(angle = 90, hjust = 0.5, vjust = 0.5))
  eclys
}
(abunvh+ecvh)/(abunlys+eclys)


# pH, threshold value is derived from MRT analysis
# log10 vh
{
  filtered_df = combine
  filtered_df$group = ifelse(combine$pH <= 3.375, "Low pH", "High pH")
  ctemp1 = data.frame(vh = filtered_df$logcvh, group2 = 'CPR',group1 = filtered_df$group)
  wilcox.test (ctemp1$vh~ctemp1$group1)
  t.test(ctemp1$vh~ctemp1$group1)
  aov(vh~group1, ctemp1)
  dtemp1 = data.frame(vh = filtered_df$logdvh, group2 = 'DPANN',group1 = filtered_df$group)
  t.test(dtemp1$vh~dtemp1$group1)
  wilcox.test (dtemp1$vh~dtemp1$group1)
  temp1 = rbind(ctemp1,dtemp1)
  p <- ggplot(temp1, aes(x = interaction(group1, group2), y = vh, fill = group1)) +
    geom_boxplot() +
    geom_jitter(width = 0.2, alpha = 0.6)+
    labs(x = "Groups", y = "Log10 vh") +
    theme_classic()+
    theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),axis.text.y = element_text(angle = 90, hjust = 0.5, vjust = 0.5))+
    theme(legend.position = "none",strip.text = element_blank())+
    theme(axis.line.y = element_line(size=0.5),axis.line.x = element_line(size=0.5),axis.text.x = element_text(size=17,color = "black"),
          axis.text.y = element_text(size=17,color="black"),axis.title.x = element_text(size=22),
          axis.title.y = element_text(size=22))
  comparisons <- list(c("Low pH.CPR", "High pH.CPR"), c("Low pH.DPANN", "High pH.DPANN"), c("Low pH.CPR", "Low pH.DPANN"), c("High pH.CPR", "High pH.DPANN"))
  ph1=p + stat_compare_means(comparisons = comparisons, method = "wilcox.test", label = "p.signif", size = 6,hide.ns = TRUE)+
    scale_fill_manual(values = c("Low pH" = "red", "High pH" = "blue"))+
    scale_x_discrete(labels = c("Low pH.CPR" = "Low pH.CPR", "High pH.CPR" = "High pH.CPR", "Low pH.DPANN" = "Low pH.DPANN", "High pH.DPANN" = "High pH.DPANN"))+
    theme(axis.text.x = element_text(angle = 45, hjust = 1))+
    theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),axis.text.y = element_text(angle = 90, hjust = 0.5, vjust = 0.5))+
    theme(legend.position = "top",strip.text = element_blank())+
    theme(axis.line.y = element_line(size=0.5),axis.line.x = element_line(size=0.5),axis.text.x = element_text(size=13,color = "black"),
          axis.text.y = element_text(size=13,color="black"),axis.title.x = element_text(size=14),
          axis.title.y = element_text(size=14))
  ph1
}
# Lysogenic rate
{
  ctemp2 = data.frame(vh = filtered_df$cLysogenic_rate, group2 = 'CPR',group1 = filtered_df$group)
  dtemp2 = data.frame(vh = filtered_df$dLysogenic_rate, group2 = 'DPANN',group1 = filtered_df$group)
  temp2 = rbind(ctemp2,dtemp2)
  p <- ggplot(temp2, aes(x = interaction(group1, group2), y = vh*100, fill = group1)) +
    geom_boxplot() +
    geom_jitter(width = 0.2, alpha = 0.6)+
    labs(x = "Groups", y = "Lysogenic_rate (%)") +
    theme_classic()+
    theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),axis.text.y = element_text(angle = 90, hjust = 0.5, vjust = 0.5))+
    theme(legend.position = "none",strip.text = element_blank())+
    theme(axis.line.y = element_line(size=0.5),axis.line.x = element_line(size=0.5),axis.text.x = element_text(size=17,color = "black"),
          axis.text.y = element_text(size=17,color="black"),axis.title.x = element_text(size=22),
          axis.title.y = element_text(size=22))
  comparisons <- list(c("Low pH.CPR", "High pH.CPR"), c("Low pH.DPANN", "High pH.DPANN"), c("Low pH.CPR", "Low pH.DPANN"), c("High pH.CPR", "High pH.DPANN"))
  ph2=p + stat_compare_means(comparisons = comparisons, method = "wilcox.test", label = "p.signif", size = 6,hide.ns = TRUE)+
    scale_fill_manual(values = c("Low pH" = "red", "High pH" = "blue"))+
    scale_x_discrete(labels = c("Low pH.CPR" = "Low pH.CPR", "High pH.CPR" = "High pH.CPR", "Low pH.DPANN" = "Low pH.DPANN", "High pH.DPANN" = "High pH.DPANN"))+
    theme(axis.text.x = element_text(angle = 45, hjust = 1))+
    theme(panel.grid.major=element_blank(),panel.grid.minor = element_blank(),axis.text.y = element_text(angle = 90, hjust = 0.5, vjust = 0.5))+
    theme(legend.position = "top",strip.text = element_blank())+
    theme(axis.line.y = element_line(size=0.5),axis.line.x = element_line(size=0.5),axis.text.x = element_text(size=13,color = "black"),
          axis.text.y = element_text(size=13,color="black"),axis.title.x = element_text(size=14),
          axis.title.y = element_text(size=14))
  ph2
}

